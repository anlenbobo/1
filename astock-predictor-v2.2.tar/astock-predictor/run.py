"""
A股状态预测系统 v2.2 — 启动入口
含自动迁移 + 反馈闭环分析引擎。
"""
import os
import logging

from flask import Flask
from sqlalchemy import inspect, text
from config import Config
from app import db
from app.api.routes import api, views

logger = logging.getLogger(__name__)

# ── SQLAlchemy 类型 → PostgreSQL DDL 映射 ──
_TYPE_MAP = {
    "VARCHAR": lambda c: f"VARCHAR({c.type.length})" if hasattr(c.type, "length") and c.type.length else "VARCHAR(50)",
    "String": lambda c: f"VARCHAR({c.type.length})" if hasattr(c.type, "length") and c.type.length else "VARCHAR(50)",
    "TEXT": lambda c: "TEXT",
    "Text": lambda c: "TEXT",
    "FLOAT": lambda c: "FLOAT",
    "Float": lambda c: "FLOAT",
    "INTEGER": lambda c: "INTEGER",
    "Integer": lambda c: "INTEGER",
    "BOOLEAN": lambda c: "BOOLEAN",
    "Boolean": lambda c: "BOOLEAN",
    "DATE": lambda c: "DATE",
    "Date": lambda c: "DATE",
    "DATETIME": lambda c: "TIMESTAMP",
    "DateTime": lambda c: "TIMESTAMP",
}


def _col_ddl_type(col):
    """将 SQLAlchemy Column 的 type 转为 PostgreSQL DDL 字符串。"""
    type_name = type(col.type).__name__
    mapper = _TYPE_MAP.get(type_name)
    if mapper:
        return mapper(col)
    return "TEXT"  # fallback


def _auto_migrate(app):
    """
    通用自动迁移：遍历所有 ORM 模型，对比数据库中已有表的列，
    自动 ALTER TABLE ADD COLUMN 补齐缺失的列。
    这样从 v1.0 升级到 v2.x 不需要手动改数据库。
    """
    with app.app_context():
        inspector = inspect(db.engine)
        existing_tables = set(inspector.get_table_names())

        # 遍历所有已注册的模型
        for mapper in db.Model.registry.mappers:
            model = mapper.class_
            table_name = model.__tablename__

            if table_name not in existing_tables:
                continue  # 新表，create_all 会处理

            # 获取数据库现有列
            db_cols = {col["name"] for col in inspector.get_columns(table_name)}

            # 获取模型定义的列
            migrations = []
            for col in model.__table__.columns:
                if col.name not in db_cols:
                    ddl_type = _col_ddl_type(col)
                    default_clause = ""
                    if col.default is not None and col.default.arg is not None:
                        default_val = col.default.arg
                        if isinstance(default_val, bool):
                            default_clause = f" DEFAULT {'TRUE' if default_val else 'FALSE'}"
                        elif isinstance(default_val, (int, float)):
                            default_clause = f" DEFAULT {default_val}"
                        elif isinstance(default_val, str):
                            default_clause = f" DEFAULT '{default_val}'"
                    migrations.append(
                        f'ALTER TABLE {table_name} ADD COLUMN "{col.name}" {ddl_type}{default_clause}'
                    )

            if migrations:
                logger.info(f"Auto-migrate [{table_name}]: adding {len(migrations)} column(s)")
                with db.engine.begin() as conn:
                    for sql in migrations:
                        logger.info(f"  -> {sql}")
                        conn.execute(text(sql))

        logger.info("Auto-migration check complete")


def create_app(config_class=Config):
    app = Flask(
        __name__,
        template_folder="app/templates",
        static_folder="app/static",
    )
    app.config.from_object(config_class)

    # 日志配置
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # 数据库
    db.init_app(app)

    # 注册蓝图
    app.register_blueprint(api)    # /api/*
    app.register_blueprint(views)  # / 页面路由

    # 确保 models_saved 目录存在
    model_dir = app.config.get("MODEL_DIR", "models_saved")
    os.makedirs(model_dir, exist_ok=True)

    # 导入模型（确保注册到 ORM 元数据）
    with app.app_context():
        from app.models import (  # noqa: F401
            Stock, DailyPrice, Feature, Signal, Prediction, BacktestResult,
            AnalysisSnapshot,
        )

        # 自动迁移旧表（必须在 create_all 之前）
        _auto_migrate(app)

        # 建表（仅处理完全不存在的新表）
        db.create_all()

    return app


def main():
    app = create_app()

    # 可选：启动定时调度器
    enable_scheduler = os.getenv("ENABLE_SCHEDULER", "false").lower() == "true"
    if enable_scheduler:
        from app.scheduler.daily_task import setup_scheduler
        setup_scheduler(app)

    host = os.getenv("FLASK_HOST", "0.0.0.0")
    port = int(os.getenv("FLASK_PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"

    app.run(host=host, port=port, debug=debug)


if __name__ == "__main__":
    main()
