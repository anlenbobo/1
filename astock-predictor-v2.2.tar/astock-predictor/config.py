import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-in-production")
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        "postgresql://postgres:postgres@localhost:5432/astock_predictor",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_size": 10,
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }

    # Data source priority: akshare > sina
    DATA_SOURCES = ["akshare", "sina"]

    # Model persistence
    MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models_saved")

    # Backtest periods
    BACKTEST_TRAIN_START = "2018-01-01"
    BACKTEST_TRAIN_END = "2022-12-31"
    BACKTEST_TEST_START = "2023-01-01"
    BACKTEST_TEST_END = "2023-12-31"
    BACKTEST_VALIDATE_START = "2024-01-01"
    BACKTEST_VALIDATE_END = "2024-12-31"

    # Scheduler
    DAILY_UPDATE_HOUR = 17  # 5 PM after market close
    DAILY_UPDATE_MINUTE = 30
