# A股状态预测系统 v2.0

多策略共识投票的A股市场状态预测引擎。

---

## 系统架构

```
app/
├── data_engine/          # 多源数据引擎（akshare → sina 降级）
│   ├── source_manager.py
│   ├── akshare_source.py
│   ├── sina_source.py
│   ├── stock_loader.py
│   ├── price_loader.py
│   └── incremental_updater.py
├── feature_engine/       # 特征工程（23维特征）
│   ├── price_features.py
│   ├── volume_features.py
│   ├── capital_features.py
│   ├── sentiment_features.py
│   └── feature_pipeline.py
├── alpha_engine/         # Alpha引擎
│   ├── market_state/     # 6态分类（吸筹/启动/主升/高位分歧/出货/退潮）
│   ├── strategy_lab/     # 多策略信号（领导者/五维/动量/状态模型）
│   ├── risk_engine/      # 风险评估（仓位/波动率/资金控制）
│   ├── consensus_engine/ # 共识投票引擎
│   └── alpha_pipeline.py
├── backtest/             # 回测验证（时间滚动法）
├── api/                  # Flask API + 页面路由
├── scheduler/            # 定时任务
├── models/               # SQLAlchemy 数据模型
└── templates/            # 前端页面（ECharts + TailwindCSS）
```

---

## 数据库搭建教程

### 1. 安装 PostgreSQL

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
```

**CentOS/RHEL:**
```bash
sudo yum install postgresql-server postgresql-contrib
sudo postgresql-setup initdb
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**macOS (Homebrew):**
```bash
brew install postgresql@15
brew services start postgresql@15
```

**Windows:**
从官网下载安装包：https://www.postgresql.org/download/windows/
安装时记住设定的超级用户密码。

### 2. 创建数据库

登录 PostgreSQL：
```bash
sudo -u postgres psql
```

执行以下 SQL：
```sql
-- 创建数据库（UTF-8 编码）
CREATE DATABASE astock_predictor
    ENCODING 'UTF8'
    LC_COLLATE 'en_US.UTF-8'
    LC_CTYPE 'en_US.UTF-8'
    TEMPLATE template0;

-- （可选）创建专用用户
CREATE USER astock_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE astock_predictor TO astock_user;

-- 连接到新数据库并授予 schema 权限
\c astock_predictor
GRANT ALL ON SCHEMA public TO astock_user;
```

如果系统的默认 locale 不包含 `en_US.UTF-8`，可改用：
```sql
CREATE DATABASE astock_predictor
    ENCODING 'UTF8'
    LC_COLLATE 'C'
    LC_CTYPE 'C'
    TEMPLATE template0;
```

验证数据库：
```bash
\l
```
应该能看到 `astock_predictor` 出现在列表中。

退出 psql：
```bash
\q
```

### 3. 配置连接

复制环境变量文件：
```bash
cp .env.example .env
```

编辑 `.env`，填入实际的数据库连接信息：
```
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/astock_predictor
SECRET_KEY=随机字符串用于Flask会话加密
```

如果创建了专用用户：
```
DATABASE_URL=postgresql://astock_user:your_secure_password@localhost:5432/astock_predictor
```

### 4. 常见问题

**Q: 连接报错 `FATAL: database "astock_predictor" does not exist`**
A: 数据库尚未创建。回到第2步执行 `CREATE DATABASE` 命令。

**Q: 编码错误 `encoding "UTF8" does not match locale "C"`**
A: 使用 `TEMPLATE template0` 参数创建数据库，或将 `LC_COLLATE` 改为 `'C'`。

**Q: 权限不足 `FATAL: role "postgres" does not exist`**
A: macOS Homebrew 安装的 PostgreSQL 默认用当前系统用户名。直接运行 `psql postgres` 即可。

**Q: 连接被拒绝 `Connection refused`**
A: 检查 PostgreSQL 服务是否启动：
```bash
sudo systemctl status postgresql
# 或
pg_isready
```

---

## 快速启动

### 1. 安装 Python 依赖

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. 配置环境

```bash
cp .env.example .env
# 编辑 .env 填入数据库连接信息
```

### 3. 启动

```bash
python run.py
```

首次启动会自动创建所有数据表。访问 `http://localhost:5000` 进入系统。

### 4. 启用定时任务（可选）

```bash
ENABLE_SCHEDULER=true python run.py
```

每个工作日 17:30 自动执行增量更新。

---

## 使用流程

### 基础流程

1. **同步股票列表**：股票管理页 → 点击「同步列表」
2. **获取行情数据**：选择股票 → 输入代码 → 运行数据流水线
3. **共识预测**：共识预测页 → 输入代码 → 查看多策略投票结果
4. **回测验证**：回测页 → 运行回测 → 查看准确率/胜率/夏普比率

### 一键流水线

在股票管理页的「数据流水线」区域，输入股票代码，一键完成：
获取行情 → 计算特征 → 状态标注 → 模型训练 → 共识预测

---

## 数据表结构

| 表名 | 说明 | 关键字段 |
|------|------|----------|
| `stocks` | 股票基础信息 | code(PK), name, sector |
| `daily_prices` | 日线行情 | code, trade_date, OHLCV, turnover_rate |
| `features` | 23维特征 + 状态标签 | code, trade_date, state_label, risk_index |
| `signals` | 策略信号 | code, strategy_name, direction, strength |
| `predictions` | 共识预测结果 | code, consensus_direction, confidence_score |
| `backtest_results` | 回测结果 | accuracy, sharpe_ratio, max_drawdown |

---

## 六态定义

| 编号 | 状态 | 含义 |
|------|------|------|
| 0 | 吸筹 | 底部区域，主力建仓 |
| 1 | 启动 | 开始上涨，适合买入 |
| 2 | 主升 | 加速拉升，趋势强劲 |
| 3 | 高位分歧 | 顶部区域，多空争夺 |
| 4 | 出货 | 主力出货，适合卖出 |
| 5 | 退潮 | 下跌趋势，回避 |
