"""
状态统计引擎 — 反馈闭环的核心。

三条统计线：
1. 状态未来收益统计（每个状态的5日/10日收益均值 + 胜率）
2. 共识分层统计（按置信度分层的方向准确率）
3. 风险指数与回撤相关性（高风险信号后是否真的跟着回撤）

所有统计支持按时间窗口分段，用于对比不同市场环境下的表现稳定性。
"""
import json
import logging
from datetime import datetime

import pandas as pd
from sqlalchemy import text

from app import db
from app.models import (
    Feature, DailyPrice, Prediction, STATE_NAMES,
)

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════
# 第一条线：状态未来收益统计
# ════════════════════════════════════════════════

def compute_state_performance(period_start=None, period_end=None):
    """
    核心统计：对每个 state_label，计算标注日之后的未来 5/10 日收益。

    返回:
    [
        {
            "state": 0, "state_name": "吸筹", "samples": 1200,
            "return_5d_mean": 0.013, "return_5d_median": 0.008,
            "return_10d_mean": 0.025, "return_10d_median": 0.018,
            "win_rate_5d": 0.56, "win_rate_10d": 0.54,
            "max_gain_5d": 0.15, "max_loss_5d": -0.08,
        },
        ...
    ]
    """
    # 拉取 features（带 state_label）和价格
    query = db.session.query(
        Feature.code, Feature.trade_date, Feature.state_label, Feature.risk_index,
    ).filter(Feature.state_label.isnot(None))

    if period_start:
        query = query.filter(Feature.trade_date >= period_start)
    if period_end:
        query = query.filter(Feature.trade_date <= period_end)

    features = query.all()
    if not features:
        return []

    # 转 DataFrame
    feat_df = pd.DataFrame(
        [(f.code, f.trade_date, f.state_label, f.risk_index) for f in features],
        columns=["code", "trade_date", "state_label", "risk_index"],
    )
    feat_df["trade_date"] = pd.to_datetime(feat_df["trade_date"])

    # 获取所有相关股票的价格
    codes = feat_df["code"].unique().tolist()
    prices_query = db.session.query(
        DailyPrice.code, DailyPrice.trade_date, DailyPrice.close,
    ).filter(DailyPrice.code.in_(codes))
    if period_start:
        prices_query = prices_query.filter(DailyPrice.trade_date >= period_start)

    prices = prices_query.order_by(DailyPrice.code, DailyPrice.trade_date).all()
    price_df = pd.DataFrame(
        [(p.code, p.trade_date, p.close) for p in prices],
        columns=["code", "trade_date", "close"],
    )
    price_df["trade_date"] = pd.to_datetime(price_df["trade_date"])

    # 为每只股票计算未来 N 日收益
    results = []
    for code in codes:
        pdf = price_df[price_df["code"] == code].sort_values("trade_date").reset_index(drop=True)
        if len(pdf) < 11:
            continue

        # 建立日期 → 索引映射
        date_to_idx = {d: i for i, d in enumerate(pdf["trade_date"])}
        closes = pdf["close"].values

        fdf = feat_df[feat_df["code"] == code]
        for _, row in fdf.iterrows():
            idx = date_to_idx.get(row["trade_date"])
            if idx is None:
                continue

            ret_5d = None
            ret_10d = None
            if idx + 5 < len(closes) and closes[idx] > 0:
                ret_5d = (closes[idx + 5] - closes[idx]) / closes[idx]
            if idx + 10 < len(closes) and closes[idx] > 0:
                ret_10d = (closes[idx + 10] - closes[idx]) / closes[idx]

            results.append({
                "state": row["state_label"],
                "risk_index": row["risk_index"],
                "ret_5d": ret_5d,
                "ret_10d": ret_10d,
            })

    if not results:
        return []

    rdf = pd.DataFrame(results)

    # 按状态聚合
    stats = []
    for state in sorted(rdf["state"].dropna().unique()):
        sdf = rdf[rdf["state"] == state]
        r5 = sdf["ret_5d"].dropna()
        r10 = sdf["ret_10d"].dropna()

        stats.append({
            "state": int(state),
            "state_name": STATE_NAMES.get(int(state), f"状态{int(state)}"),
            "samples": len(sdf),
            "return_5d_mean": round(float(r5.mean()), 6) if len(r5) > 0 else None,
            "return_5d_median": round(float(r5.median()), 6) if len(r5) > 0 else None,
            "return_10d_mean": round(float(r10.mean()), 6) if len(r10) > 0 else None,
            "return_10d_median": round(float(r10.median()), 6) if len(r10) > 0 else None,
            "win_rate_5d": round(float((r5 > 0).mean()), 4) if len(r5) > 0 else None,
            "win_rate_10d": round(float((r10 > 0).mean()), 4) if len(r10) > 0 else None,
            "max_gain_5d": round(float(r5.max()), 6) if len(r5) > 0 else None,
            "max_loss_5d": round(float(r5.min()), 6) if len(r5) > 0 else None,
        })

    return stats


def compute_state_performance_by_period(periods=None):
    """
    按时间段分段统计，用于对比不同市场环境下的状态稳定性。

    periods: [("2018-01-01", "2020-12-31"), ("2021-01-01", "2023-12-31"), ...]
    如果不传，自动按年份分段。
    """
    if periods is None:
        # 自动按年份分段
        min_date = db.session.query(db.func.min(Feature.trade_date)).filter(
            Feature.state_label.isnot(None)
        ).scalar()
        max_date = db.session.query(db.func.max(Feature.trade_date)).filter(
            Feature.state_label.isnot(None)
        ).scalar()

        if not min_date or not max_date:
            return {}

        periods = []
        year = min_date.year
        while year <= max_date.year:
            periods.append((f"{year}-01-01", f"{year}-12-31"))
            year += 1

    result = {}
    for start, end in periods:
        label = f"{start[:4]}" if start[:4] == end[:4] else f"{start[:4]}-{end[:4]}"
        result[label] = compute_state_performance(start, end)

    return result


# ════════════════════════════════════════════════
# 第二条线：共识分层统计
# ════════════════════════════════════════════════

def compute_consensus_accuracy(period_start=None, period_end=None):
    """
    统计共识预测的准确性：
    - 按方向(buy/sell/hold)分组
    - 按置信度分层(0-30%, 30-60%, 60%+)
    - 计算每层的未来5日收益和方向准确率

    buy 信号正确 = 未来5日涨; sell 信号正确 = 未来5日跌
    """
    query = db.session.query(
        Prediction.code, Prediction.trade_date,
        Prediction.consensus_direction, Prediction.confidence_score,
        Prediction.risk_index,
    )

    if period_start:
        query = query.filter(Prediction.trade_date >= period_start)
    if period_end:
        query = query.filter(Prediction.trade_date <= period_end)

    preds = query.all()
    if not preds:
        return []

    pred_df = pd.DataFrame(
        [(p.code, p.trade_date, p.consensus_direction, p.confidence_score, p.risk_index)
         for p in preds],
        columns=["code", "trade_date", "direction", "confidence", "risk_index"],
    )
    pred_df["trade_date"] = pd.to_datetime(pred_df["trade_date"])

    # 获取价格数据
    codes = pred_df["code"].unique().tolist()
    prices = db.session.query(
        DailyPrice.code, DailyPrice.trade_date, DailyPrice.close,
    ).filter(DailyPrice.code.in_(codes)).order_by(DailyPrice.code, DailyPrice.trade_date).all()

    price_df = pd.DataFrame(
        [(p.code, p.trade_date, p.close) for p in prices],
        columns=["code", "trade_date", "close"],
    )
    price_df["trade_date"] = pd.to_datetime(price_df["trade_date"])

    # 计算未来收益
    records = []
    for code in codes:
        pf = price_df[price_df["code"] == code].sort_values("trade_date").reset_index(drop=True)
        if len(pf) < 6:
            continue
        date_idx = {d: i for i, d in enumerate(pf["trade_date"])}
        closes = pf["close"].values

        cdf = pred_df[pred_df["code"] == code]
        for _, row in cdf.iterrows():
            idx = date_idx.get(row["trade_date"])
            if idx is None or idx + 5 >= len(closes) or closes[idx] <= 0:
                continue
            ret_5d = (closes[idx + 5] - closes[idx]) / closes[idx]
            records.append({
                "direction": row["direction"],
                "confidence": row["confidence"],
                "ret_5d": ret_5d,
            })

    if not records:
        return []

    rdf = pd.DataFrame(records)

    # 置信度分层
    def conf_tier(c):
        if c is None:
            return "unknown"
        if c < 0.3:
            return "low"
        if c < 0.6:
            return "medium"
        return "high"

    rdf["conf_tier"] = rdf["confidence"].apply(conf_tier)

    stats = []
    for direction in ["buy", "sell", "hold"]:
        ddf = rdf[rdf["direction"] == direction]
        if len(ddf) == 0:
            continue

        for tier in ["low", "medium", "high"]:
            tdf = ddf[ddf["conf_tier"] == tier]
            if len(tdf) == 0:
                continue

            r5 = tdf["ret_5d"]
            if direction == "buy":
                correct = (r5 > 0).mean()
            elif direction == "sell":
                correct = (r5 < 0).mean()
            else:
                correct = (r5.abs() < 0.02).mean()  # hold 正确 = 波动不大

            stats.append({
                "direction": direction,
                "confidence_tier": tier,
                "samples": len(tdf),
                "accuracy": round(float(correct), 4),
                "return_5d_mean": round(float(r5.mean()), 6),
                "return_5d_std": round(float(r5.std()), 6) if len(r5) > 1 else None,
            })

    return stats


# ════════════════════════════════════════════════
# 第三条线：风险指数与回撤相关性
# ════════════════════════════════════════════════

def compute_risk_drawdown_correlation(period_start=None, period_end=None):
    """
    验证风险引擎：高风险指数之后是否真的跟着回撤。

    按风险指数分层(0-30, 30-60, 60-100)，
    统计每层的未来5日最大回撤和平均收益。
    """
    query = db.session.query(
        Feature.code, Feature.trade_date, Feature.risk_index,
    ).filter(Feature.risk_index.isnot(None))

    if period_start:
        query = query.filter(Feature.trade_date >= period_start)
    if period_end:
        query = query.filter(Feature.trade_date <= period_end)

    features = query.all()
    if not features:
        return []

    feat_df = pd.DataFrame(
        [(f.code, f.trade_date, f.risk_index) for f in features],
        columns=["code", "trade_date", "risk_index"],
    )
    feat_df["trade_date"] = pd.to_datetime(feat_df["trade_date"])

    codes = feat_df["code"].unique().tolist()
    prices = db.session.query(
        DailyPrice.code, DailyPrice.trade_date, DailyPrice.close, DailyPrice.low,
    ).filter(DailyPrice.code.in_(codes)).order_by(DailyPrice.code, DailyPrice.trade_date).all()

    price_df = pd.DataFrame(
        [(p.code, p.trade_date, p.close, p.low) for p in prices],
        columns=["code", "trade_date", "close", "low"],
    )
    price_df["trade_date"] = pd.to_datetime(price_df["trade_date"])

    records = []
    for code in codes:
        pf = price_df[price_df["code"] == code].sort_values("trade_date").reset_index(drop=True)
        if len(pf) < 6:
            continue
        date_idx = {d: i for i, d in enumerate(pf["trade_date"])}
        closes = pf["close"].values
        lows = pf["low"].values

        fdf = feat_df[feat_df["code"] == code]
        for _, row in fdf.iterrows():
            idx = date_idx.get(row["trade_date"])
            if idx is None or idx + 5 >= len(closes) or closes[idx] <= 0:
                continue

            # 未来5日的最大回撤 = (entry_close - min_low_in_5d) / entry_close
            future_lows = lows[idx + 1:idx + 6]
            max_drawdown_5d = (closes[idx] - future_lows.min()) / closes[idx]
            ret_5d = (closes[idx + 5] - closes[idx]) / closes[idx]

            records.append({
                "risk_index": row["risk_index"],
                "max_drawdown_5d": max_drawdown_5d,
                "ret_5d": ret_5d,
            })

    if not records:
        return []

    rdf = pd.DataFrame(records)

    def risk_tier(r):
        if r < 30:
            return "low"
        if r < 60:
            return "medium"
        return "high"

    rdf["risk_tier"] = rdf["risk_index"].apply(risk_tier)

    stats = []
    for tier in ["low", "medium", "high"]:
        tdf = rdf[rdf["risk_tier"] == tier]
        if len(tdf) == 0:
            continue

        stats.append({
            "risk_tier": tier,
            "risk_range": {"low": "0-30", "medium": "30-60", "high": "60-100"}[tier],
            "samples": len(tdf),
            "avg_drawdown_5d": round(float(tdf["max_drawdown_5d"].mean()), 6),
            "median_drawdown_5d": round(float(tdf["max_drawdown_5d"].median()), 6),
            "avg_return_5d": round(float(tdf["ret_5d"].mean()), 6),
            "drawdown_over_5pct_rate": round(float((tdf["max_drawdown_5d"] > 0.05).mean()), 4),
        })

    return stats


# ════════════════════════════════════════════════
# 快照：保存统计结果用于版本对比
# ════════════════════════════════════════════════

def save_snapshot(label=None):
    """
    生成全量统计并存入 analysis_snapshots 表。
    label: 自定义标签（如 "调整突破阈值前"、"v2.2"）
    """
    from app.models import AnalysisSnapshot

    state_perf = compute_state_performance()
    consensus = compute_consensus_accuracy()
    risk_corr = compute_risk_drawdown_correlation()
    by_period = compute_state_performance_by_period()

    snapshot = AnalysisSnapshot(
        label=label or f"snapshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        state_performance_json=json.dumps(state_perf, ensure_ascii=False),
        consensus_accuracy_json=json.dumps(consensus, ensure_ascii=False),
        risk_correlation_json=json.dumps(risk_corr, ensure_ascii=False),
        period_breakdown_json=json.dumps(by_period, ensure_ascii=False),
    )
    db.session.add(snapshot)
    db.session.commit()

    logger.info(f"Analysis snapshot saved: {snapshot.label} (id={snapshot.id})")
    return snapshot.id


def get_snapshot_list():
    """获取所有快照的摘要列表。"""
    from app.models import AnalysisSnapshot
    snapshots = AnalysisSnapshot.query.order_by(AnalysisSnapshot.created_at.desc()).all()
    return [{
        "id": s.id,
        "label": s.label,
        "created_at": s.created_at.isoformat() if s.created_at else None,
    } for s in snapshots]


def get_snapshot_detail(snapshot_id):
    """获取单个快照的完整数据。"""
    from app.models import AnalysisSnapshot
    s = AnalysisSnapshot.query.get(snapshot_id)
    if not s:
        return None
    return {
        "id": s.id,
        "label": s.label,
        "created_at": s.created_at.isoformat() if s.created_at else None,
        "state_performance": json.loads(s.state_performance_json) if s.state_performance_json else [],
        "consensus_accuracy": json.loads(s.consensus_accuracy_json) if s.consensus_accuracy_json else [],
        "risk_correlation": json.loads(s.risk_correlation_json) if s.risk_correlation_json else [],
        "period_breakdown": json.loads(s.period_breakdown_json) if s.period_breakdown_json else {},
    }
