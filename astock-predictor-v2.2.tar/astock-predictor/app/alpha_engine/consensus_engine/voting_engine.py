"""
投票引擎 — 汇总各策略信号，加权投票产生共识。
"""
import json
import logging
from datetime import datetime

from app import db
from app.models import Prediction, STATE_NAMES
from app.alpha_engine.strategy_lab.signal_generator import generate_signals
from app.alpha_engine.market_state.state_predictor import predict_stock_state
from app.alpha_engine.risk_engine.position_risk import evaluate_position_risk
from app.alpha_engine.consensus_engine.role_manager import get_role_weight
from app.alpha_engine.consensus_engine.confidence_score import compute_confidence

logger = logging.getLogger(__name__)

DIRECTION_SCORES = {"buy": 1, "hold": 0, "sell": -1}


def run_consensus(code: str, model_dir: str = "models_saved") -> dict:
    """
    对单只股票执行完整共识流程:
    1. 运行所有策略获取信号
    2. 运行状态预测模型
    3. 加权投票
    4. 计算置信度
    5. 综合风险评估
    6. 存储结果

    返回完整的共识结论 dict。
    """
    trade_date = datetime.now().date()

    # Step 1: 策略信号
    signals = generate_signals(code, trade_date)

    # Step 2: 状态预测
    state_result = predict_stock_state(code, model_dir=model_dir)
    state_vote = _state_to_vote(state_result)
    if state_vote:
        signals.append(state_vote)

    # Step 3: 加权投票
    weighted_sum = 0
    total_weight = 0
    vote_details = []

    for sig in signals:
        name = sig.get("strategy_name", "unknown")
        direction = sig.get("direction", "hold")
        strength = sig.get("strength", 0)
        weight = sig.get("weight", get_role_weight(name))

        dir_score = DIRECTION_SCORES.get(direction, 0) * strength
        weighted_sum += dir_score * weight
        total_weight += weight

        vote_details.append({
            "role": name,
            "direction": direction,
            "strength": strength,
            "weight": weight,
            "score": round(dir_score * weight, 4),
            "reason": sig.get("reason", ""),
        })

    # 共识方向
    if total_weight > 0:
        consensus_score = weighted_sum / total_weight
    else:
        consensus_score = 0

    if consensus_score > 0.3:
        consensus_direction = "buy"
    elif consensus_score < -0.3:
        consensus_direction = "sell"
    else:
        consensus_direction = "hold"

    # Step 4: 置信度
    confidence = compute_confidence(signals, consensus_direction)

    # Step 5: 风险
    risk_info = evaluate_position_risk(code)

    # Step 6: 存储
    pred = Prediction(
        code=code,
        trade_date=trade_date,
        predicted_state=state_result["predicted_state"] if state_result else None,
        prob_accumulate=state_result["probabilities"].get("吸筹", 0) if state_result else 0,
        prob_launch=state_result["probabilities"].get("启动", 0) if state_result else 0,
        prob_surge=state_result["probabilities"].get("主升", 0) if state_result else 0,
        prob_diverge=state_result["probabilities"].get("高位分歧", 0) if state_result else 0,
        prob_distribute=state_result["probabilities"].get("出货", 0) if state_result else 0,
        prob_decline=state_result["probabilities"].get("退潮", 0) if state_result else 0,
        consensus_direction=consensus_direction,
        confidence_score=confidence,
        risk_index=risk_info["risk_score"],
        risk_level=risk_info["level"],
        votes_json=json.dumps(vote_details, ensure_ascii=False),
    )
    db.session.add(pred)
    db.session.commit()

    return {
        "code": code,
        "trade_date": str(trade_date),
        "consensus_direction": consensus_direction,
        "consensus_score": round(consensus_score, 4),
        "confidence": round(confidence, 4),
        "risk_index": risk_info["risk_score"],
        "risk_level": risk_info["level"],
        "risk_factors": risk_info["factors"],
        "state": state_result,
        "votes": vote_details,
    }


def run_consensus_batch(codes: list, model_dir: str = "models_saved") -> list:
    """批量共识。"""
    results = []
    for code in codes:
        try:
            r = run_consensus(code, model_dir)
            results.append(r)
        except Exception as e:
            logger.error(f"Consensus failed for {code}: {e}")
    return results


def _state_to_vote(state_result: dict) -> dict:
    """将状态预测结果转换为投票格式。"""
    if not state_result:
        return None

    state = state_result["predicted_state"]
    # 状态 1/2 (启动/主升) → buy, 状态 4/5 (出货/退潮) → sell
    if state in (1, 2):
        direction = "buy"
    elif state in (4, 5):
        direction = "sell"
    else:
        direction = "hold"

    # 强度 = 最大概率值
    max_prob = max(state_result["probabilities"].values()) if state_result["probabilities"] else 0

    return {
        "strategy_name": "state_model",
        "direction": direction,
        "strength": max_prob,
        "weight": get_role_weight("state_model"),
        "reason": f"状态: {state_result['state_name']} (P={max_prob:.2f})",
    }
