"""
置信度计算 — 衡量各策略投票的一致性。
一致性越高 → 置信度越高。
"""


def compute_confidence(signals: list, consensus_direction: str) -> float:
    """
    计算共识置信度 (0~1)。

    基于:
    1. 方向一致性: 有多少策略投票方向与共识一致
    2. 强度均值: 一致策略的平均信号强度
    3. 权重覆盖: 一致策略占总权重的比例

    Args:
        signals: 各策略信号列表
        consensus_direction: 最终共识方向 (buy/sell/hold)

    Returns:
        float: 0~1 的置信度
    """
    if not signals:
        return 0.0

    total_weight = sum(s.get("weight", 0.25) for s in signals)
    if total_weight == 0:
        return 0.0

    agree_weight = 0
    agree_strengths = []

    for sig in signals:
        sig_dir = sig.get("direction", "hold")
        weight = sig.get("weight", 0.25)
        strength = sig.get("strength", 0)

        if sig_dir == consensus_direction:
            agree_weight += weight
            agree_strengths.append(strength)
        elif consensus_direction == "hold" and sig_dir == "hold":
            agree_weight += weight * 0.5  # hold 与 hold 半权认同

    # 一致性比例
    agreement_ratio = agree_weight / total_weight

    # 平均强度
    avg_strength = sum(agree_strengths) / len(agree_strengths) if agree_strengths else 0

    # 综合置信度
    confidence = 0.6 * agreement_ratio + 0.4 * avg_strength

    return round(min(max(confidence, 0), 1), 4)
