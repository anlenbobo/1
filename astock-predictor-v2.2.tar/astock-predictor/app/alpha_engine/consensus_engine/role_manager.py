"""
角色管理器 — 定义策略角色及其权重。
每个策略扮演一个"分析师角色"参与投票。
"""

ROLES = {
    "leader": {
        "display_name": "龙头猎手",
        "description": "专注于板块龙头股的识别，擅长捕捉领涨机会",
        "weight": 0.35,
        "expertise": ["breakout", "sector_leader", "volume_surge"],
    },
    "five_dimension": {
        "display_name": "五维分析师",
        "description": "多维度共振分析，综合趋势、量能、资金、位置、情绪",
        "weight": 0.30,
        "expertise": ["trend", "volume", "capital", "position", "sentiment"],
    },
    "momentum": {
        "display_name": "趋势追踪者",
        "description": "基于价格动量判断趋势延续性",
        "weight": 0.20,
        "expertise": ["momentum", "trend_continuation"],
    },
    "state_model": {
        "display_name": "状态识别师",
        "description": "机器学习模型判断当前所处的主力运作阶段",
        "weight": 0.15,
        "expertise": ["state_classification", "cycle_position"],
    },
}


def get_role(name: str) -> dict:
    return ROLES.get(name, {})


def get_all_roles() -> dict:
    return ROLES.copy()


def get_role_weight(name: str) -> float:
    return ROLES.get(name, {}).get("weight", 0)
