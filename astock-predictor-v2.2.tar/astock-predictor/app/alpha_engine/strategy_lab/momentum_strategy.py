"""
动量策略。
基于短期价格动量和趋势延续性判断方向。
"""
import logging

from app.models import Feature

logger = logging.getLogger(__name__)


class MomentumStrategy:
    """动量策略"""

    name = "momentum"
    weight = 0.20

    def evaluate(self, code: str) -> dict:
        # 获取最近10条特征
        features = (
            Feature.query.filter_by(code=code)
            .order_by(Feature.trade_date.desc())
            .limit(10)
            .all()
        )
        if len(features) < 5:
            return {"direction": "hold", "strength": 0, "reason": "数据不足"}

        latest = features[0]
        score = 0
        reasons = []

        # 短期动量: 5日涨幅
        ret5 = latest.stage_return_5d or 0
        if ret5 > 0.05:
            score += 0.3
            reasons.append(f"5日涨幅{ret5*100:.1f}%")
        elif ret5 < -0.05:
            score -= 0.3
            reasons.append(f"5日跌幅{ret5*100:.1f}%")

        # 中期动量: 20日涨幅
        ret20 = latest.stage_return_20d or 0
        if ret20 > 0.1:
            score += 0.25
            reasons.append(f"20日涨幅{ret20*100:.1f}%")
        elif ret20 < -0.1:
            score -= 0.25
            reasons.append(f"20日跌幅{ret20*100:.1f}%")

        # 动量加速: 近5日是否持续正收益
        recent_slopes = [f.ma5_slope or 0 for f in features[:5]]
        positive_days = sum(1 for s in recent_slopes if s > 0)
        if positive_days >= 4:
            score += 0.25
            reasons.append("动量持续加速")
        elif positive_days <= 1:
            score -= 0.25
            reasons.append("动量持续衰减")

        # 突破确认
        if latest.breakout_flag == 1:
            score += 0.2
            reasons.append("价格突破")

        # 判断方向
        if score >= 0.4:
            direction = "buy"
        elif score <= -0.4:
            direction = "sell"
        else:
            direction = "hold"

        return {
            "direction": direction,
            "strength": round(min(abs(score), 1.0), 3),
            "reason": "，".join(reasons) if reasons else "动量中性",
        }
