"""
信号生成器 — 汇总所有策略的评估结果，写入 signals 表。
"""
import logging
from datetime import datetime

from app import db
from app.models import Signal
from app.alpha_engine.strategy_lab.leader_strategy import LeaderStrategy
from app.alpha_engine.strategy_lab.five_dimension import FiveDimensionStrategy
from app.alpha_engine.strategy_lab.momentum_strategy import MomentumStrategy

logger = logging.getLogger(__name__)

# 注册所有策略
ALL_STRATEGIES = [LeaderStrategy(), FiveDimensionStrategy(), MomentumStrategy()]


def generate_signals(code: str, trade_date=None) -> list:
    """
    运行所有策略，生成信号并存储。
    返回 [{strategy_name, direction, strength, reason}, ...]
    """
    if trade_date is None:
        trade_date = datetime.now().date()

    results = []
    for strategy in ALL_STRATEGIES:
        try:
            result = strategy.evaluate(code)
            result["strategy_name"] = strategy.name
            result["weight"] = strategy.weight
            results.append(result)

            # 写入数据库
            sig = Signal(
                code=code,
                trade_date=trade_date,
                strategy_name=strategy.name,
                direction=result["direction"],
                strength=result["strength"],
                reason=result["reason"],
            )
            db.session.add(sig)
        except Exception as e:
            logger.error(f"Strategy {strategy.name} failed for {code}: {e}")
            results.append({
                "strategy_name": strategy.name,
                "direction": "hold",
                "strength": 0,
                "reason": f"Error: {e}",
                "weight": strategy.weight,
            })

    db.session.commit()
    return results


def generate_signals_batch(codes: list, trade_date=None) -> dict:
    """批量生成信号。返回 {code: [signals]}"""
    all_results = {}
    for code in codes:
        all_results[code] = generate_signals(code, trade_date)
    return all_results
