"""
龙头战法策略。
核心逻辑: 识别板块中率先突破、资金集中的领涨股。
"""
import logging

from app.models import Feature

logger = logging.getLogger(__name__)


class LeaderStrategy:
    """龙头股策略"""

    name = "leader"
    weight = 0.35  # 共识投票权重

    def evaluate(self, code: str) -> dict:
        """
        评估是否符合龙头特征。
        返回 {direction, strength, reason}
        """
        feat = (
            Feature.query.filter_by(code=code)
            .order_by(Feature.trade_date.desc())
            .first()
        )
        if not feat:
            return {"direction": "hold", "strength": 0, "reason": "无数据"}

        score = 0
        reasons = []

        # 条件1: 突破阶段高点
        if feat.breakout_flag == 1:
            score += 0.3
            reasons.append("突破阶段高点")

        # 条件2: 放量 (5日量变 > 50%)
        if (feat.volume_change_5d or 0) > 0.5:
            score += 0.25
            reasons.append("显著放量")

        # 条件3: 板块强势 (排名前30%)
        if (feat.sector_strength_rank or 0.5) < 0.3:
            score += 0.2
            reasons.append("板块领涨")

        # 条件4: 资金净流入
        if (feat.net_inflow or 0) > 0:
            score += 0.15
            reasons.append("主力净流入")

        # 条件5: 趋势向上
        if (feat.ma5_slope or 0) > 0 and (feat.ma20_slope or 0) > 0:
            score += 0.1
            reasons.append("均线多头")

        # 判断方向
        if score >= 0.6:
            direction = "buy"
        elif score <= 0.2:
            direction = "sell"
        else:
            direction = "hold"

        return {
            "direction": direction,
            "strength": round(min(score, 1.0), 3),
            "reason": "，".join(reasons) if reasons else "无明显信号",
        }
