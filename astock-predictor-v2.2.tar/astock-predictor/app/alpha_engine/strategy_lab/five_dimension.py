"""
五维共振策略。
五个维度: 趋势、量能、资金、位置、情绪。
当多维度同时确认时信号最强。
"""
import logging

from app.models import Feature

logger = logging.getLogger(__name__)


class FiveDimensionStrategy:
    """五维共振策略"""

    name = "five_dimension"
    weight = 0.30

    def evaluate(self, code: str) -> dict:
        feat = (
            Feature.query.filter_by(code=code)
            .order_by(Feature.trade_date.desc())
            .first()
        )
        if not feat:
            return {"direction": "hold", "strength": 0, "reason": "无数据"}

        dims = {}

        # 维度1: 趋势 (均线斜率)
        ma5 = feat.ma5_slope or 0
        ma20 = feat.ma20_slope or 0
        if ma5 > 0.01 and ma20 > 0:
            dims["趋势"] = 1
        elif ma5 < -0.01 and ma20 < 0:
            dims["趋势"] = -1
        else:
            dims["趋势"] = 0

        # 维度2: 量能 (放量配合)
        vol_chg = feat.volume_change_5d or 0
        if vol_chg > 0.3:
            dims["量能"] = 1
        elif vol_chg < -0.3:
            dims["量能"] = -1
        else:
            dims["量能"] = 0

        # 维度3: 资金 (净流入)
        inflow = feat.net_inflow or 0
        cont = feat.inflow_continuous_days or 0
        if inflow > 0 and cont >= 2:
            dims["资金"] = 1
        elif inflow < 0:
            dims["资金"] = -1
        else:
            dims["资金"] = 0

        # 维度4: 位置 (高低位)
        pos = feat.high_position_ratio or 0.5
        if pos < 0.3:
            dims["位置"] = 1   # 低位有空间
        elif pos > 0.8:
            dims["位置"] = -1  # 高位有风险
        else:
            dims["位置"] = 0

        # 维度5: 情绪 (市场环境)
        sent = feat.market_sentiment_score or 0.5
        if sent > 0.7:
            dims["情绪"] = 1
        elif sent < 0.3:
            dims["情绪"] = -1
        else:
            dims["情绪"] = 0

        # 综合评分
        total = sum(dims.values())
        positive = sum(1 for v in dims.values() if v > 0)
        negative = sum(1 for v in dims.values() if v < 0)

        confirmed = [k for k, v in dims.items() if v > 0]
        warned = [k for k, v in dims.items() if v < 0]

        if total >= 3:
            direction = "buy"
            strength = min(positive / 5, 1.0)
        elif total <= -3:
            direction = "sell"
            strength = min(negative / 5, 1.0)
        else:
            direction = "hold"
            strength = abs(total) / 5

        parts = []
        if confirmed:
            parts.append(f"确认: {','.join(confirmed)}")
        if warned:
            parts.append(f"警示: {','.join(warned)}")
        reason = "；".join(parts) if parts else "中性"

        return {
            "direction": direction,
            "strength": round(strength, 3),
            "reason": reason,
            "dimensions": dims,
        }
