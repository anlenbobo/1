"""
Alpha 管线总入口 — 串联状态预测 + 策略信号 + 风控 + 共识投票。
"""
import logging

from app.alpha_engine.market_state.state_labeler import label_batch
from app.alpha_engine.market_state.state_trainer import train_state_model
from app.alpha_engine.consensus_engine.voting_engine import run_consensus, run_consensus_batch

logger = logging.getLogger(__name__)


def run_alpha_pipeline(codes: list, model_dir: str = "models_saved",
                       train_start: str = None, train_end: str = None) -> dict:
    """
    完整 Alpha 管线:
    1. 标注状态
    2. 训练模型 (可选)
    3. 共识投票

    返回 {labels, training, consensus}
    """
    results = {}

    # Step 1: 标注
    logger.info("=== Alpha Pipeline: Labeling ===")
    n_labeled = label_batch(codes)
    results["labels"] = n_labeled

    # Step 2: 训练 (如果提供了日期范围)
    if train_start and train_end:
        logger.info("=== Alpha Pipeline: Training ===")
        model, scaler, metrics = train_state_model(train_start, train_end, model_dir)
        results["training"] = metrics
    else:
        results["training"] = None

    # Step 3: 共识
    logger.info("=== Alpha Pipeline: Consensus ===")
    consensus = run_consensus_batch(codes, model_dir)
    results["consensus"] = consensus

    return results
