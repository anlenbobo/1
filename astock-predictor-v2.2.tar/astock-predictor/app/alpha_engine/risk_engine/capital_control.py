"""
资金管理 / 仓位控制。
根据风险水平计算建议仓位。
"""
import logging

from app.alpha_engine.risk_engine.position_risk import evaluate_position_risk
from app.alpha_engine.risk_engine.volatility_risk import compute_volatility

logger = logging.getLogger(__name__)


def compute_position_size(code: str, total_capital: float = 1000000,
                          max_single_position: float = 0.2) -> dict:
    """
    基于风险评估计算建议仓位。

    Args:
        code: 股票代码
        total_capital: 总资金
        max_single_position: 单票最大仓位比例

    Returns:
        {suggested_pct, suggested_amount, risk_adjusted_size, reasoning}
    """
    pos_risk = evaluate_position_risk(code)
    vol_info = compute_volatility(code)

    risk_score = pos_risk["risk_score"]
    vol_factor = 1 - vol_info["risk_contribution"]  # 波动越大仓位越小

    # 基础仓位 = 最大仓位 × (1 - 风险得分/100)
    base_pct = max_single_position * (1 - risk_score / 100)

    # 波动率调整
    adjusted_pct = base_pct * max(vol_factor, 0.2)  # 最低保留20%

    # 约束
    adjusted_pct = max(0, min(adjusted_pct, max_single_position))
    amount = total_capital * adjusted_pct

    reasoning = []
    if risk_score >= 60:
        reasoning.append("高风险，建议轻仓或回避")
    elif risk_score >= 30:
        reasoning.append("中等风险，建议控制仓位")
    else:
        reasoning.append("风险可控，可正常建仓")

    if vol_info["volatility_ratio"] > 1.5:
        reasoning.append("近期波动放大，降低仓位")

    return {
        "suggested_pct": round(adjusted_pct, 4),
        "suggested_amount": round(amount, 0),
        "max_single_position": max_single_position,
        "risk_score": risk_score,
        "risk_level": pos_risk["level"],
        "risk_factors": pos_risk["factors"],
        "volatility": vol_info,
        "reasoning": "；".join(reasoning),
    }
