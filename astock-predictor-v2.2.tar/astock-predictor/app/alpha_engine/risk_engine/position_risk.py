"""
持仓风险评估。
基于个股位置和状态评估单票风险。
"""
import logging
import numpy as np

from app.models import Feature

logger = logging.getLogger(__name__)


def evaluate_position_risk(code: str) -> dict:
    """
    评估持仓风险。
    返回 {risk_score, level, factors}
    """
    feat = (
        Feature.query.filter_by(code=code)
        .order_by(Feature.trade_date.desc())
        .first()
    )
    if not feat:
        return {"risk_score": 50, "level": "中风险", "factors": ["无数据"]}

    factors = []
    score = 0

    # 高位风险
    pos = feat.high_position_ratio or 0
    if pos > 0.8:
        score += 30
        factors.append(f"高位运行({pos*100:.0f}%)")
    elif pos > 0.6:
        score += 15
        factors.append(f"中高位({pos*100:.0f}%)")

    # 量价背离
    vpd = feat.volume_price_divergence or 0
    if vpd > 3:
        score += 25
        factors.append("严重量价背离")
    elif vpd > 1:
        score += 10
        factors.append("轻微量价背离")

    # 上影线
    shadow = feat.upper_shadow_ratio or 0
    if shadow > 0.4:
        score += 15
        factors.append("长上影线")

    # 高换手
    if feat.high_turnover_flag == 1:
        score += 10
        factors.append("异常高换手")

    # 资金流出
    if (feat.net_inflow or 0) < 0:
        score += 10
        factors.append("主力净流出")

    # 下跌趋势
    if (feat.ma5_slope or 0) < -0.02 and (feat.ma20_slope or 0) < 0:
        score += 10
        factors.append("均线空头排列")

    score = min(score, 100)
    level = "低风险" if score < 30 else ("中风险" if score < 60 else "高风险")

    return {
        "risk_score": score,
        "level": level,
        "factors": factors if factors else ["风险可控"],
    }
