"""
波动率风险评估。
基于历史波动率和波动率变化判断风险。
"""
import logging
import numpy as np
import pandas as pd

from app.models import DailyPrice

logger = logging.getLogger(__name__)


def compute_volatility(code: str, window: int = 20) -> dict:
    """
    计算个股波动率相关指标。
    返回 {volatility_20d, volatility_ratio, atr_pct, risk_contribution}
    """
    prices = (
        DailyPrice.query.filter_by(code=code)
        .order_by(DailyPrice.trade_date.desc())
        .limit(60)
        .all()
    )
    if len(prices) < window:
        return {"volatility_20d": 0, "volatility_ratio": 1, "atr_pct": 0, "risk_contribution": 0}

    prices = list(reversed(prices))
    closes = np.array([p.close for p in prices])
    highs = np.array([p.high for p in prices])
    lows = np.array([p.low for p in prices])

    # 日收益率标准差 (年化)
    returns = np.diff(np.log(closes))
    vol_20 = float(np.std(returns[-window:]) * np.sqrt(252))

    # 波动率比值: 近期 vs 长期
    vol_10 = float(np.std(returns[-10:]) * np.sqrt(252)) if len(returns) >= 10 else vol_20
    vol_ratio = vol_10 / vol_20 if vol_20 > 0 else 1.0

    # ATR 百分比
    tr = np.maximum(highs[1:] - lows[1:],
                    np.maximum(np.abs(highs[1:] - closes[:-1]),
                               np.abs(lows[1:] - closes[:-1])))
    atr = float(np.mean(tr[-window:])) if len(tr) >= window else 0
    atr_pct = atr / closes[-1] * 100 if closes[-1] > 0 else 0

    # 风险贡献度 (0~1)
    risk_contribution = min(vol_20 / 0.6, 1.0)  # 年化60%波动率为满分

    return {
        "volatility_20d": round(vol_20, 4),
        "volatility_ratio": round(vol_ratio, 3),  # >1 表示波动放大
        "atr_pct": round(atr_pct, 2),
        "risk_contribution": round(risk_contribution, 3),
    }
