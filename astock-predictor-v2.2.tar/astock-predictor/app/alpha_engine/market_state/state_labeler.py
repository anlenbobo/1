"""
状态标注器 — 基于规则的启发式标注。
为模型训练提供初始监督标签。
"""
import logging

from app import db
from app.models import Feature, STATE_NAMES

logger = logging.getLogger(__name__)


def label_single_stock(code: str) -> int:
    """
    对单只股票的全部特征行应用规则标注。
    状态定义:
        0 吸筹: 低位、低量、窄幅震荡
        1 启动: 低位突破 + 放量
        2 主升: 持续上涨、趋势良好
        3 高位分歧: 高位放量、上影线
        4 出货: 高位下跌、带量
        5 退潮: 持续下跌、缩量

    返回标注行数。
    """
    features = (
        Feature.query.filter_by(code=code)
        .order_by(Feature.trade_date.asc())
        .all()
    )
    if not features:
        return 0

    count = 0
    for f in features:
        pos = f.high_position_ratio or 0
        ret5 = f.stage_return_5d or 0
        ret20 = f.stage_return_20d or 0
        vol_chg = f.volume_change_5d or 0
        breakout = f.breakout_flag or 0
        shadow = f.upper_shadow_ratio or 0
        ma5s = f.ma5_slope or 0
        ma20s = f.ma20_slope or 0

        if pos < 0.3 and abs(ret5) < 0.05 and abs(vol_chg) < 0.5:
            state = 0  # 吸筹
        elif pos < 0.5 and breakout == 1 and vol_chg > 0.3:
            state = 1  # 启动
        elif pos > 0.5 and ret5 > 0.05 and ma5s > 0 and ma20s > 0:
            state = 2  # 主升
        elif pos > 0.7 and shadow > 0.3 and vol_chg > 0.5:
            state = 3  # 高位分歧
        elif pos > 0.6 and ret5 < -0.03 and vol_chg > 0:
            state = 4  # 出货
        elif pos > 0.3 and ret5 < -0.05 and ma5s < 0:
            state = 5  # 退潮
        elif pos > 0.6 and ret5 > 0.03:
            state = 2  # 主升 (补充规则)
        elif pos < 0.4 and ma5s < 0 and ret5 < -0.03:
            state = 5  # 退潮 (低位下跌)
        else:
            state = 0  # 默认: 吸筹

        f.state_label = state
        count += 1

    db.session.commit()
    logger.info(f"{code}: labeled {count} rows")
    return count


def label_batch(codes: list) -> int:
    """批量标注。"""
    total = 0
    for code in codes:
        try:
            total += label_single_stock(code)
        except Exception as e:
            logger.error(f"Labeling error for {code}: {e}")
            db.session.rollback()
    return total
