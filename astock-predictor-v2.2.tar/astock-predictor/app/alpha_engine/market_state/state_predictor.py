"""
状态预测器 — 对个股输出状态概率分布。
"""
import logging

import numpy as np

from app.models import Feature, STATE_NAMES, FEATURE_COLUMNS
from app.alpha_engine.market_state.state_trainer import load_latest_model

logger = logging.getLogger(__name__)


def predict_stock_state(code: str, model=None, scaler=None,
                        model_dir: str = "models_saved") -> dict:
    """
    预测单只股票最新状态。
    返回:
        {code, trade_date, predicted_state, state_name, probabilities, risk_index}
    """
    if model is None or scaler is None:
        model, scaler = load_latest_model(model_dir)
        if model is None:
            return None

    feature = (
        Feature.query.filter_by(code=code)
        .order_by(Feature.trade_date.desc())
        .first()
    )
    if not feature:
        return None

    X = np.array([[getattr(feature, col, 0) or 0 for col in FEATURE_COLUMNS]])
    X_scaled = scaler.transform(X)

    pred = int(model.predict(X_scaled)[0])
    probs = model.predict_proba(X_scaled)[0]

    prob_dict = {}
    for i, cls in enumerate(model.classes_):
        prob_dict[STATE_NAMES.get(int(cls), str(cls))] = round(float(probs[i]), 4)

    return {
        "code": code,
        "trade_date": str(feature.trade_date),
        "predicted_state": pred,
        "state_name": STATE_NAMES.get(pred, "未知"),
        "probabilities": prob_dict,
        "risk_index": float(feature.risk_index or 0),
    }


def predict_batch(codes: list, model_dir: str = "models_saved") -> list:
    """批量预测。"""
    model, scaler = load_latest_model(model_dir)
    if model is None:
        return []
    return [
        r for code in codes
        if (r := predict_stock_state(code, model, scaler, model_dir)) is not None
    ]
