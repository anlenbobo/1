"""
状态预测模型训练器。
使用 sklearn LogisticRegression 多分类。
"""
import json
import logging
import os
import pickle
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report

from app import db
from app.models import Feature, STATE_NAMES, FEATURE_COLUMNS

logger = logging.getLogger(__name__)


def _get_labeled_data(start_date=None, end_date=None) -> pd.DataFrame:
    """从数据库读取已标注的特征数据。"""
    query = Feature.query.filter(Feature.state_label.isnot(None))
    if start_date:
        query = query.filter(Feature.trade_date >= start_date)
    if end_date:
        query = query.filter(Feature.trade_date <= end_date)

    rows = []
    for f in query.order_by(Feature.trade_date.asc()).all():
        row = {"code": f.code, "trade_date": f.trade_date, "state_label": f.state_label}
        for col in FEATURE_COLUMNS:
            row[col] = getattr(f, col, 0) or 0
        rows.append(row)
    return pd.DataFrame(rows)


def train_state_model(train_start: str, train_end: str,
                      model_dir: str = "models_saved") -> tuple:
    """
    训练状态预测模型。
    返回 (model, scaler, metrics_dict)
    """
    df = _get_labeled_data(train_start, train_end)
    if df.empty:
        logger.error("No training data!")
        return None, None, {}

    logger.info(f"Training: {len(df)} samples [{train_start} ~ {train_end}]")
    logger.info(f"State distribution:\n{df['state_label'].value_counts().sort_index()}")

    X = df[FEATURE_COLUMNS].fillna(0).values
    y = df["state_label"].values

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = LogisticRegression(
        max_iter=1000,
        multi_class="multinomial",
        solver="lbfgs",
        class_weight="balanced",
        C=1.0,
    )
    model.fit(X_scaled, y)

    y_pred = model.predict(X_scaled)
    acc = accuracy_score(y, y_pred)
    report = classification_report(
        y, y_pred,
        target_names=[STATE_NAMES[i] for i in sorted(set(y))],
        output_dict=True,
    )

    metrics = {
        "train_accuracy": float(acc),
        "n_samples": len(df),
        "state_distribution": df["state_label"].value_counts().to_dict(),
        "classification_report": report,
    }

    # 持久化
    os.makedirs(model_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    for obj, name in [(model, "model"), (scaler, "scaler")]:
        with open(os.path.join(model_dir, f"{name}_{ts}.pkl"), "wb") as f:
            pickle.dump(obj, f)
        with open(os.path.join(model_dir, f"{name}_latest.pkl"), "wb") as f:
            pickle.dump(obj, f)

    logger.info(f"Model saved, train accuracy: {acc:.4f}")
    return model, scaler, metrics


def load_latest_model(model_dir: str = "models_saved"):
    """加载最新模型和 scaler。"""
    mp = os.path.join(model_dir, "model_latest.pkl")
    sp = os.path.join(model_dir, "scaler_latest.pkl")
    if not os.path.exists(mp):
        return None, None
    with open(mp, "rb") as f:
        model = pickle.load(f)
    with open(sp, "rb") as f:
        scaler = pickle.load(f)
    return model, scaler
