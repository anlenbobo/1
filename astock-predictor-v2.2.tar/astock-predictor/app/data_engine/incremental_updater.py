"""
增量更新器 — 只拉取数据库中已有股票的最新数据。
"""
import logging
from datetime import datetime, timedelta

from app import db
from app.models import Stock, DailyPrice
from app.data_engine.source_manager import SourceManager
from app.data_engine.price_loader import load_daily_prices

logger = logging.getLogger(__name__)


def get_last_trade_date(code: str):
    """获取某只股票在库中的最新交易日。"""
    latest = (
        DailyPrice.query.filter_by(code=code)
        .order_by(DailyPrice.trade_date.desc())
        .first()
    )
    return latest.trade_date if latest else None


def incremental_update(codes: list = None, source_mgr: SourceManager = None) -> dict:
    """
    增量更新：只获取每只股票最新日期之后的数据。
    如果 codes 为 None，则更新所有 is_active=True 的股票。
    返回 {code: new_records_count}
    """
    if source_mgr is None:
        source_mgr = SourceManager()

    if codes is None:
        stocks = Stock.query.filter_by(is_active=True).all()
        codes = [s.code for s in stocks]

    results = {}
    for i, code in enumerate(codes):
        logger.info(f"[{i+1}/{len(codes)}] Incremental update: {code}")
        last_date = get_last_trade_date(code)
        if last_date:
            start = (last_date + timedelta(days=1)).strftime("%Y%m%d")
        else:
            start = "20180101"

        today = datetime.now().strftime("%Y%m%d")
        if start > today:
            results[code] = 0
            continue

        try:
            n = load_daily_prices(code, start_date=start, source_mgr=source_mgr)
            results[code] = n
        except Exception as e:
            logger.error(f"Incremental update failed for {code}: {e}")
            results[code] = -1
            db.session.rollback()

    total = sum(v for v in results.values() if v > 0)
    logger.info(f"Incremental update complete: {total} new records across {len(codes)} stocks")
    return results
