"""
新浪财经数据源实现 — 作为 akshare 的降级备选。
使用 akshare 内部封装的新浪接口。
"""
import logging
from datetime import datetime

import pandas as pd

logger = logging.getLogger(__name__)


class SinaSource:
    """基于新浪财经的备选数据源。"""

    def fetch_stock_list(self) -> pd.DataFrame:
        """新浪接口获取股票列表（通过 akshare 的新浪接口）。"""
        try:
            import akshare as ak
            df = ak.stock_info_a_code_name()
            return pd.DataFrame({
                "code": df["code"].astype(str),
                "name": df["name"].astype(str),
                "sector": "",
            })
        except Exception as e:
            logger.error(f"Sina stock list failed: {e}")
            return None

    def fetch_daily_price(self, code: str, start_date: str = "20180101",
                          end_date: str = None) -> pd.DataFrame:
        """新浪日线数据备选（通过 akshare 的新浪通道）。"""
        try:
            import akshare as ak
            prefix = "sh" if code.startswith("6") else "sz"
            symbol = f"{prefix}{code}"
            df = ak.stock_zh_a_daily(symbol=symbol, adjust="qfq")
            if df is None or df.empty:
                return None

            df["trade_date"] = pd.to_datetime(df["date"]).dt.date
            start = datetime.strptime(start_date, "%Y%m%d").date()
            df = df[df["trade_date"] >= start]

            if end_date:
                end = datetime.strptime(end_date, "%Y%m%d").date()
                df = df[df["trade_date"] <= end]

            return pd.DataFrame({
                "trade_date": df["trade_date"],
                "open": df["open"].astype(float),
                "high": df["high"].astype(float),
                "low": df["low"].astype(float),
                "close": df["close"].astype(float),
                "volume": df["volume"].astype(float),
                "amount": df.get("amount", pd.Series(0)).astype(float),
                "turnover_rate": 0.0,
                "pct_chg": 0.0,
            })
        except Exception as e:
            logger.error(f"Sina daily price failed for {code}: {e}")
            return None

    def fetch_northbound_flow(self) -> pd.DataFrame:
        return None

    def fetch_limit_up(self, trade_date: str) -> dict:
        return None

    def fetch_capital_flow(self, code: str) -> pd.DataFrame:
        return None
