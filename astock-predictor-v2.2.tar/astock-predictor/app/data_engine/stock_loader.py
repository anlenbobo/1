"""
股票列表加载器 — 从数据源同步到数据库。
"""
import logging

from app import db
from app.models import Stock
from app.data_engine.source_manager import SourceManager

logger = logging.getLogger(__name__)


def sync_stock_list(source_mgr: SourceManager = None) -> int:
    """同步 A 股列表到 stocks 表，返回新增数量。"""
    if source_mgr is None:
        source_mgr = SourceManager()

    df = source_mgr.call("fetch_stock_list")
    if df is None or df.empty:
        logger.error("Failed to fetch stock list from any source")
        return 0

    count = 0
    for _, row in df.iterrows():
        code = str(row["code"]).strip()
        existing = Stock.query.get(code)
        if not existing:
            stock = Stock(
                code=code,
                name=str(row["name"]),
                sector=str(row.get("sector", "")),
                market="sh" if code.startswith("6") else ("bj" if code.startswith("8") else "sz"),
                is_active=True,
            )
            db.session.add(stock)
            count += 1
        else:
            existing.name = str(row["name"])
            if row.get("sector"):
                existing.sector = str(row["sector"])

    db.session.commit()
    logger.info(f"Stock list synced: {count} new, {len(df)} total")
    return count
