"""
数据源管理器 — 统一接口，自动降级。
优先使用 akshare，失败时降级到 sina。
"""
import logging

logger = logging.getLogger(__name__)


class SourceManager:
    """管理多个数据源，按优先级尝试获取数据。"""

    def __init__(self, source_priority=None):
        self.sources = {}
        self.priority = source_priority or ["akshare", "sina"]
        self._register_sources()

    def _register_sources(self):
        from app.data_engine.akshare_source import AkshareSource
        from app.data_engine.sina_source import SinaSource
        self.sources["akshare"] = AkshareSource()
        self.sources["sina"] = SinaSource()

    def call(self, method_name: str, **kwargs):
        """
        按优先级调用数据源方法。
        返回第一个成功的结果，全部失败则返回 None。
        """
        for name in self.priority:
            source = self.sources.get(name)
            if not source:
                continue
            fn = getattr(source, method_name, None)
            if not fn:
                continue
            try:
                result = fn(**kwargs)
                if result is not None:
                    logger.info(f"[{name}] {method_name} succeeded")
                    return result
            except Exception as e:
                logger.warning(f"[{name}] {method_name} failed: {e}")
                continue
        logger.error(f"All sources failed for {method_name}")
        return None
