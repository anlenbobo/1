"""
akshare 数据源实现。
"""
import logging
from datetime import datetime

import akshare as ak
import pandas as pd

logger = logging.getLogger(__name__)


class AkshareSource:
    """基于 akshare 的数据采集（免费、无需 API Key）。"""

    def fetch_stock_list(self) -> pd.DataFrame:
        """获取全部 A 股列表，返回 DataFrame[code, name, sector]"""
        df = ak.stock_zh_a_spot_em()
        result = pd.DataFrame({
            "code": df["代码"].astype(str),
            "name": df["名称"].astype(str),
            "sector": df.get("所属行业", pd.Series("")).astype(str),
        })
        return result

    def fetch_daily_price(self, code: str, start_date: str = "20180101",
                          end_date: str = None) -> pd.DataFrame:
        """
        获取单只股票日线数据（前复权）。
        返回 DataFrame[trade_date, open, high, low, close, volume, amount, turnover_rate, pct_chg]
        """
        if end_date is None:
            end_date = datetime.now().strftime("%Y%m%d")

        df = ak.stock_zh_a_hist(
            symbol=code, period="daily",
            start_date=start_date, end_date=end_date, adjust="qfq",
        )
        if df is None or df.empty:
            return None

        result = pd.DataFrame({
            "trade_date": pd.to_datetime(df["日期"]).dt.date,
            "open": df["开盘"].astype(float),
            "high": df["最高"].astype(float),
            "low": df["最低"].astype(float),
            "close": df["收盘"].astype(float),
            "volume": df["成交量"].astype(float),
            "amount": df["成交额"].astype(float),
            "turnover_rate": df.get("换手率", pd.Series(0)).astype(float),
            "pct_chg": df.get("涨跌幅", pd.Series(0)).astype(float),
        })
        return result

    def fetch_northbound_flow(self) -> pd.DataFrame:
        """获取北向资金净流入，返回 DataFrame[date, net]"""
        df = ak.stock_hsgt_north_net_flow_in_em(symbol="北上")
        result = pd.DataFrame({
            "date": pd.to_datetime(df["日期"]).dt.date,
            "net": df["当日净流入"].astype(float),
        })
        return result.set_index("date")

    def fetch_limit_up(self, trade_date: str) -> dict:
        """获取涨停统计，返回 {limit_up_count, max_board_height}"""
        df = ak.stock_zt_pool_em(date=trade_date)
        if df is None or df.empty:
            return {"limit_up_count": 0, "max_board_height": 0}
        return {
            "limit_up_count": len(df),
            "max_board_height": int(df["连板数"].max()) if "连板数" in df.columns else 1,
        }

    def fetch_capital_flow(self, code: str) -> pd.DataFrame:
        """获取个股资金流向，返回 DataFrame[date, net_inflow, big_order_ratio]"""
        market = "sh" if code.startswith("6") else "sz"
        df = ak.stock_individual_fund_flow(stock=code, market=market)
        if df is None or df.empty:
            return None
        result = pd.DataFrame({
            "date": pd.to_datetime(df["日期"]).dt.date,
            "net_inflow": df["主力净流入-净额"].astype(float),
            "big_order_ratio": df.get("超大单净额", pd.Series(0)).astype(float),
        })
        return result.set_index("date")
