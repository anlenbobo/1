"""
行情数据加载器 — 批量拉取日线数据写入 daily_price 表。
"""
import logging

import pandas as pd

from app import db
from app.models import DailyPrice
from app.data_engine.source_manager import SourceManager

logger = logging.getLogger(__name__)


def load_daily_prices(code: str, start_date: str = "20180101", end_date: str = None,
                      source_mgr: SourceManager = None) -> int:
    """获取单股日线数据并写入数据库，返回新增行数。"""
    if source_mgr is None:
        source_mgr = SourceManager()

    df = source_mgr.call("fetch_daily_price", code=code,
                         start_date=start_date, end_date=end_date)
    if df is None or df.empty:
        logger.warning(f"No price data for {code}")
        return 0

    count = 0
    for _, row in df.iterrows():
        td = row["trade_date"]
        if DailyPrice.query.get((code, td)):
            continue
        price = DailyPrice(
            code=code,
            trade_date=td,
            open=float(row["open"]),
            high=float(row["high"]),
            low=float(row["low"]),
            close=float(row["close"]),
            volume=float(row["volume"]),
            amount=float(row["amount"]),
            turnover_rate=float(row.get("turnover_rate", 0)),
            pct_chg=float(row.get("pct_chg", 0)),
        )
        db.session.add(price)
        count += 1

    db.session.commit()
    logger.info(f"{code}: {count} new price records")
    return count


def load_daily_prices_batch(codes: list, start_date: str = "20180101",
                            end_date: str = None, source_mgr: SourceManager = None) -> int:
    """批量拉取多只股票日线。"""
    if source_mgr is None:
        source_mgr = SourceManager()
    total = 0
    for i, code in enumerate(codes):
        logger.info(f"[{i+1}/{len(codes)}] Loading prices for {code}")
        try:
            total += load_daily_prices(code, start_date, end_date, source_mgr)
        except Exception as e:
            logger.error(f"Error loading {code}: {e}")
            db.session.rollback()
    return total
