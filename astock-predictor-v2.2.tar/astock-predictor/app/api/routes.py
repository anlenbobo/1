"""
Flask API 路由 + 页面路由。
适配前端模板的完整接口层。
"""
import json
import logging
from datetime import datetime

from flask import Blueprint, jsonify, request, render_template, current_app
from sqlalchemy import func

from app import db
from app.models import Stock, DailyPrice, Feature, Signal, Prediction, BacktestResult
from app.models import STATE_NAMES, STATE_COLORS, FEATURE_COLUMNS

from app.data_engine.source_manager import SourceManager
from app.data_engine.stock_loader import sync_stock_list
from app.data_engine.price_loader import load_daily_prices, load_daily_prices_batch
from app.data_engine.incremental_updater import incremental_update
from app.feature_engine.feature_pipeline import run_feature_pipeline, run_feature_pipeline_batch
from app.alpha_engine.market_state.state_labeler import label_batch
from app.alpha_engine.market_state.state_trainer import train_state_model
from app.alpha_engine.market_state.state_predictor import predict_stock_state, predict_batch
from app.alpha_engine.consensus_engine.voting_engine import run_consensus, run_consensus_batch
from app.alpha_engine.risk_engine.capital_control import compute_position_size
from app.alpha_engine.alpha_pipeline import run_alpha_pipeline
from app.backtest.engine import run_backtest, run_full_validation
from app.backtest.report import get_backtest_history, get_backtest_detail
from app.analysis_engine.state_statistics import (
    compute_state_performance, compute_state_performance_by_period,
    compute_consensus_accuracy, compute_risk_drawdown_correlation,
    save_snapshot, get_snapshot_list, get_snapshot_detail,
)

logger = logging.getLogger(__name__)

api = Blueprint("api", __name__, url_prefix="/api")
views = Blueprint("views", __name__)


# ════════════════════════════════════════
# Page routes
# ════════════════════════════════════════

@views.route("/")
def index():
    return render_template("index.html")

@views.route("/stocks")
def stocks_page():
    return render_template("stocks.html")

@views.route("/stocks/<code>")
@views.route("/stock/<code>")
def stock_detail(code):
    stock = Stock.query.get(code)
    return render_template("stock_detail.html", stock=stock, code=code)

@views.route("/predict")
def predict_page():
    return render_template("predict.html")

@views.route("/backtest")
def backtest_page():
    return render_template("backtest.html")

@views.route("/analysis")
def analysis_page():
    return render_template("analysis.html")


# ════════════════════════════════════════
# Stock APIs
# ════════════════════════════════════════

@api.route("/stocks", methods=["GET"])
def api_stocks():
    """股票列表（前端客户端过滤，一次返回全部）。"""
    per_page = request.args.get("per_page", 5000, type=int)
    search = request.args.get("search", "")

    query = Stock.query
    if search:
        query = query.filter(
            db.or_(Stock.code.like(f"%{search}%"), Stock.name.like(f"%{search}%"))
        )

    stocks = query.order_by(Stock.code).limit(per_page).all()
    return jsonify({
        "stocks": [{"code": s.code, "name": s.name, "sector": s.sector or ""} for s in stocks],
    })


@api.route("/stocks/sync", methods=["POST"])
def api_sync_stocks():
    try:
        count = sync_stock_list()
        return jsonify({"status": "ok", "new_stocks": count})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/stocks/<code>/fetch", methods=["POST"])
def api_fetch_single_stock(code):
    """获取单只股票行情。"""
    try:
        n = load_daily_prices(code, start_date="20180101")
        return jsonify({"status": "ok", "records_added": n})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/stocks/<code>/features", methods=["POST"])
def api_compute_single_features(code):
    """计算单只股票特征。"""
    try:
        n = run_feature_pipeline(code)
        return jsonify({"status": "ok", "features_computed": n})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/stocks/<code>/detail", methods=["GET"])
def api_stock_detail(code):
    """
    股票详情页聚合接口。
    返回行情 + 特征 + 最新共识。
    """
    limit = request.args.get("limit", 250, type=int)
    prices = (
        DailyPrice.query.filter_by(code=code)
        .order_by(DailyPrice.trade_date.desc())
        .limit(limit)
        .all()
    )
    price_list = [{
        "date": str(p.trade_date), "open": p.open, "high": p.high,
        "low": p.low, "close": p.close, "volume": p.volume,
        "amount": p.amount, "turnover_rate": p.turnover_rate,
    } for p in reversed(prices)]

    features = (
        Feature.query.filter_by(code=code)
        .order_by(Feature.trade_date.desc())
        .limit(120)
        .all()
    )
    feature_list = [{
        "date": str(f.trade_date),
        "state": f.state_label,
        "state_name": f.state_name,
        "risk_index": f.risk_index,
        "high_position_ratio": f.high_position_ratio,
        "ma5_slope": f.ma5_slope,
        "ma20_slope": f.ma20_slope,
        "breakout": f.breakout_flag,
        "return_5d": f.stage_return_5d,
        "volume_change": f.volume_change_5d,
        "vol_price_divergence": f.volume_price_divergence,
        "market_sentiment_score": f.market_sentiment_score,
    } for f in reversed(features)]

    latest_state = None
    risk_index = None
    return_5d = None
    high_pos = None
    if features:
        latest = features[0]
        latest_state = latest.state_label
        risk_index = latest.risk_index
        return_5d = latest.stage_return_5d
        high_pos = latest.high_position_ratio

    latest_pred = (
        Prediction.query.filter_by(code=code)
        .order_by(Prediction.created_at.desc())
        .first()
    )
    consensus = None
    if latest_pred:
        votes = json.loads(latest_pred.votes_json) if latest_pred.votes_json else []
        strategy_votes = {}
        for v in votes:
            strategy_votes[v.get("role", v.get("strategy_name", "unknown"))] = {
                "direction": v.get("direction", "hold"),
                "confidence": v.get("strength", 0),
                "state": latest_pred.predicted_state,
            }
        consensus = {
            "direction": latest_pred.consensus_direction,
            "confidence": latest_pred.confidence_score,
            "risk_index": latest_pred.risk_index,
            "risk_level": latest_pred.risk_level,
            "strategy_votes": strategy_votes,
        }

    return jsonify({
        "prices": price_list,
        "features": feature_list,
        "latest_state": latest_state,
        "risk_index": risk_index,
        "return_5d": return_5d,
        "high_position_ratio": high_pos,
        "consensus": consensus,
    })


# ════════════════════════════════════════
# Price APIs
# ════════════════════════════════════════

@api.route("/prices/fetch", methods=["POST"])
def api_fetch_prices():
    data = request.get_json()
    codes = data.get("codes", [])
    start_date = data.get("start_date", "20180101")
    if not codes:
        return jsonify({"status": "error", "message": "No codes"}), 400
    total = load_daily_prices_batch(codes, start_date)
    return jsonify({"status": "ok", "records_added": total})


@api.route("/prices/update", methods=["POST"])
def api_incremental_update():
    data = request.get_json() or {}
    codes = data.get("codes")
    results = incremental_update(codes)
    total = sum(v for v in results.values() if v > 0)
    return jsonify({"status": "ok", "total_new": total, "details": results})


@api.route("/prices/<code>", methods=["GET"])
def api_get_prices(code):
    limit = request.args.get("limit", 250, type=int)
    prices = DailyPrice.query.filter_by(code=code).order_by(DailyPrice.trade_date.desc()).limit(limit).all()
    return jsonify({
        "code": code,
        "prices": [{
            "date": str(p.trade_date), "open": p.open, "high": p.high,
            "low": p.low, "close": p.close, "volume": p.volume,
            "amount": p.amount, "turnover_rate": p.turnover_rate,
        } for p in reversed(prices)],
    })


# ════════════════════════════════════════
# Feature APIs
# ════════════════════════════════════════

@api.route("/features/compute", methods=["POST"])
def api_compute_features():
    data = request.get_json()
    codes = data.get("codes", [])
    if not codes:
        return jsonify({"status": "error", "message": "No codes"}), 400
    total = run_feature_pipeline_batch(codes)
    return jsonify({"status": "ok", "features_computed": total})


@api.route("/features/<code>", methods=["GET"])
def api_get_features(code):
    limit = request.args.get("limit", 60, type=int)
    features = Feature.query.filter_by(code=code).order_by(Feature.trade_date.desc()).limit(limit).all()
    return jsonify({
        "code": code,
        "features": [{
            "date": str(f.trade_date), "state_label": f.state_label,
            "state_name": f.state_name, "risk_index": f.risk_index,
            "high_position_ratio": f.high_position_ratio,
            "ma5_slope": f.ma5_slope, "ma20_slope": f.ma20_slope,
            "breakout_flag": f.breakout_flag, "stage_return_5d": f.stage_return_5d,
            "volume_change_5d": f.volume_change_5d,
            "volume_price_divergence": f.volume_price_divergence,
            "market_sentiment_score": f.market_sentiment_score,
        } for f in reversed(features)],
    })


# ════════════════════════════════════════
# Alpha engine APIs
# ════════════════════════════════════════

@api.route("/labels/generate", methods=["POST"])
def api_generate_labels():
    data = request.get_json()
    codes = data.get("codes", [])
    if not codes:
        return jsonify({"status": "error", "message": "No codes"}), 400
    total = label_batch(codes)
    return jsonify({"status": "ok", "labels_generated": total})


@api.route("/model/train", methods=["POST"])
def api_train_model():
    data = request.get_json() or {}
    train_start = data.get("train_start", current_app.config["BACKTEST_TRAIN_START"])
    train_end = data.get("train_end", current_app.config["BACKTEST_TRAIN_END"])
    model_dir = current_app.config.get("MODEL_DIR", "models_saved")
    model, scaler, metrics = train_state_model(train_start, train_end, model_dir)
    if model is None:
        return jsonify({"status": "error", "message": "Training failed"}), 500
    return jsonify({"status": "ok", "metrics": metrics})


@api.route("/predict/<code>", methods=["GET"])
def api_predict_stock(code):
    model_dir = current_app.config.get("MODEL_DIR", "models_saved")
    result = predict_stock_state(code, model_dir=model_dir)
    if result is None:
        return jsonify({"status": "error", "message": "No model or features"}), 404
    return jsonify({"status": "ok", "prediction": result})


@api.route("/consensus/<code>", methods=["GET", "POST"])
def api_consensus_single(code):
    """单股共识预测。"""
    model_dir = current_app.config.get("MODEL_DIR", "models_saved")
    result = run_consensus(code, model_dir)

    votes_map = {}
    for v in result.get("votes", []):
        votes_map[v.get("role", "unknown")] = {
            "direction": v.get("direction", "hold"),
            "confidence": v.get("strength", 0),
            "state": result.get("state", {}).get("predicted_state") if result.get("state") else None,
        }

    return jsonify({
        "direction": result.get("consensus_direction", "hold"),
        "confidence": result.get("confidence", 0),
        "risk_index": result.get("risk_index", 0),
        "risk_level": result.get("risk_level", "--"),
        "strategy_votes": votes_map,
    })


@api.route("/consensus/batch", methods=["POST"])
def api_consensus_batch():
    """批量共识预测。"""
    data = request.get_json()
    codes = data.get("codes", [])
    model_dir = current_app.config.get("MODEL_DIR", "models_saved")

    raw_results = run_consensus_batch(codes, model_dir)

    results = []
    for r in raw_results:
        state_info = r.get("state") or {}
        probs = state_info.get("probabilities", {})

        state_probs = {}
        for state_idx, state_name in STATE_NAMES.items():
            state_probs[state_idx] = probs.get(state_name, 0)

        strategy_votes = {}
        for v in r.get("votes", []):
            strategy_votes[v.get("role", "unknown")] = {
                "direction": v.get("direction", "hold"),
                "confidence": v.get("strength", 0),
            }

        results.append({
            "code": r.get("code"),
            "date": r.get("trade_date"),
            "direction": r.get("consensus_direction", "hold"),
            "confidence": r.get("confidence", 0),
            "risk_index": r.get("risk_index", 0),
            "risk_level": r.get("risk_level", "--"),
            "predicted_state": state_info.get("predicted_state"),
            "state_probabilities": state_probs,
            "probabilities": state_probs,
            "strategy_votes": strategy_votes,
        })

    return jsonify({"results": results})


@api.route("/risk/<code>", methods=["GET"])
def api_risk_assessment(code):
    result = compute_position_size(code)
    return jsonify({"status": "ok", "risk": result})


# ════════════════════════════════════════
# Backtest APIs
# ════════════════════════════════════════

@api.route("/backtest/run", methods=["POST"])
def api_run_backtest():
    data = request.get_json() or {}
    metrics = run_backtest(
        data.get("train_start", current_app.config["BACKTEST_TRAIN_START"]),
        data.get("train_end", current_app.config["BACKTEST_TRAIN_END"]),
        data.get("test_start", current_app.config["BACKTEST_TEST_START"]),
        data.get("test_end", current_app.config["BACKTEST_TEST_END"]),
    )
    if metrics is None:
        return jsonify({"status": "error", "message": "Insufficient data"}), 500

    return jsonify({
        "status": "ok",
        "metrics": {
            "accuracy": metrics.get("accuracy"),
            "win_rate": metrics.get("state1_5d_win_rate"),
            "max_drawdown": metrics.get("max_drawdown"),
            "profit_loss_ratio": metrics.get("profit_loss_ratio"),
            "sharpe_ratio": metrics.get("sharpe_ratio"),
            "total_return": metrics.get("total_return"),
            "total_trades": metrics.get("total_trades"),
        },
        "confusion_matrix": metrics.get("confusion_matrix"),
        "classification_report": metrics.get("classification_report"),
        "details": {
            "equity_curve": metrics.get("equity_curve"),
        },
    })


@api.route("/backtest/validate", methods=["POST"])
def api_run_full_backtest():
    """完整两阶段验证。"""
    from config import Config
    results = run_full_validation(Config)

    test = results.get("test_phase") or {}
    return jsonify({
        "status": "ok",
        "metrics": {
            "accuracy": test.get("accuracy"),
            "win_rate": test.get("state1_5d_win_rate"),
            "max_drawdown": test.get("max_drawdown"),
            "profit_loss_ratio": test.get("profit_loss_ratio"),
            "sharpe_ratio": test.get("sharpe_ratio"),
            "total_return": test.get("total_return"),
            "total_trades": test.get("total_trades"),
        },
        "confusion_matrix": test.get("confusion_matrix"),
        "classification_report": test.get("classification_report"),
        "details": {
            "equity_curve": test.get("equity_curve"),
        },
        "phases": results,
    })


@api.route("/backtest/history", methods=["GET"])
def api_backtest_history():
    history = get_backtest_history()
    records = []
    for h in history:
        parts = h.get("train_period", "").split(" ~ ")
        test_parts = h.get("test_period", "").split(" ~ ")
        records.append({
            "timestamp": h.get("run_date"),
            "train_start": parts[0] if len(parts) > 0 else "",
            "train_end": parts[1] if len(parts) > 1 else "",
            "test_start": test_parts[0] if len(test_parts) > 0 else "",
            "test_end": test_parts[1] if len(test_parts) > 1 else "",
            "accuracy": h.get("accuracy"),
            "win_rate": h.get("state1_5d_win_rate"),
            "max_drawdown": h.get("max_drawdown"),
            "profit_loss_ratio": h.get("profit_loss_ratio"),
            "sharpe_ratio": h.get("sharpe_ratio"),
            "total_return": h.get("total_return"),
            "total_trades": h.get("total_trades"),
        })
    return jsonify({"records": records})


@api.route("/backtest/<int:result_id>", methods=["GET"])
def api_backtest_detail(result_id):
    detail = get_backtest_detail(result_id)
    if not detail:
        return jsonify({"status": "error", "message": "Not found"}), 404
    return jsonify({"status": "ok", "result": detail})


# ════════════════════════════════════════
# Pipeline API
# ════════════════════════════════════════

@api.route("/pipeline/run", methods=["POST"])
def api_run_pipeline():
    """全流程: 获取行情 -> 计算特征 -> 标注 -> 训练 -> 共识。"""
    data = request.get_json() or {}
    codes = data.get("codes", [])
    start_date = data.get("start_date", "20180101")
    if not codes:
        return jsonify({"status": "error", "message": "No codes"}), 400

    config = current_app.config
    pipeline_steps = []

    try:
        n = load_daily_prices_batch(codes, start_date)
        pipeline_steps.append({"step": "获取行情", "success": True, "message": f"新增 {n} 条记录"})
    except Exception as e:
        pipeline_steps.append({"step": "获取行情", "success": False, "message": str(e)})

    try:
        n = run_feature_pipeline_batch(codes)
        pipeline_steps.append({"step": "计算特征", "success": True, "message": f"生成 {n} 条特征"})
    except Exception as e:
        pipeline_steps.append({"step": "计算特征", "success": False, "message": str(e)})

    try:
        model_dir = config.get("MODEL_DIR", "models_saved")
        alpha_result = run_alpha_pipeline(
            codes, model_dir,
            train_start=config["BACKTEST_TRAIN_START"],
            train_end=config["BACKTEST_TRAIN_END"],
        )
        n_labels = alpha_result.get("labels", 0)
        n_consensus = len(alpha_result.get("consensus", []))
        training = alpha_result.get("training")
        acc = training.get("train_accuracy", 0) if training else 0

        pipeline_steps.append({"step": "状态标注", "success": True, "message": f"标注 {n_labels} 条"})
        pipeline_steps.append({"step": "模型训练", "success": True, "message": f"准确率 {acc*100:.1f}%"})
        pipeline_steps.append({"step": "共识预测", "success": True, "message": f"完成 {n_consensus} 只"})
    except Exception as e:
        pipeline_steps.append({"step": "Alpha管线", "success": False, "message": str(e)})

    results = {}
    for code in codes:
        results[code] = {"success": True, "steps": pipeline_steps}

    return jsonify({"status": "ok", "results": results, "message": "流水线执行完成"})


# ════════════════════════════════════════
# Dashboard API
# ════════════════════════════════════════

@api.route("/dashboard/summary", methods=["GET"])
def api_dashboard_summary():
    total_stocks = db.session.query(func.count(Stock.code)).scalar() or 0
    total_prices = db.session.query(func.count(DailyPrice.code)).scalar() or 0
    total_features = db.session.query(func.count(Feature.code)).scalar() or 0
    labeled = db.session.query(func.count(Feature.code)).filter(Feature.state_label.isnot(None)).scalar() or 0
    latest_bt = BacktestResult.query.order_by(BacktestResult.run_date.desc()).first()

    state_dist = (
        db.session.query(Feature.state_label, func.count())
        .filter(Feature.state_label.isnot(None))
        .group_by(Feature.state_label)
        .all()
    )

    return jsonify({
        "total_stocks": total_stocks,
        "price_records": total_prices,
        "features": total_features,
        "labeled": labeled,
        "state_distribution": {str(s): c for s, c in state_dist},
        "latest_backtest": {
            "accuracy": latest_bt.accuracy,
            "win_rate": latest_bt.state1_5d_win_rate,
            "max_drawdown": latest_bt.max_drawdown,
            "profit_loss_ratio": latest_bt.profit_loss_ratio,
            "sharpe_ratio": latest_bt.sharpe_ratio,
            "total_return": latest_bt.total_return,
        } if latest_bt else None,
    })


# ════════════════════════════════════════
# Analysis Engine APIs (反馈闭环)
# ════════════════════════════════════════

@api.route("/analysis/state-stats", methods=["GET"])
def api_state_stats():
    """状态未来收益统计 — 反馈闭环核心。"""
    period_start = request.args.get("start")
    period_end = request.args.get("end")
    try:
        stats = compute_state_performance(period_start, period_end)
        return jsonify({"status": "ok", "stats": stats})
    except Exception as e:
        logger.error(f"State stats failed: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/analysis/state-stats/by-period", methods=["GET"])
def api_state_stats_by_period():
    """按时间段分段统计，对比不同市场环境。"""
    try:
        result = compute_state_performance_by_period()
        return jsonify({"status": "ok", "periods": result})
    except Exception as e:
        logger.error(f"Period stats failed: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/analysis/consensus-accuracy", methods=["GET"])
def api_consensus_accuracy():
    """共识分层统计 — 验证置信度是否有区分力。"""
    period_start = request.args.get("start")
    period_end = request.args.get("end")
    try:
        stats = compute_consensus_accuracy(period_start, period_end)
        return jsonify({"status": "ok", "stats": stats})
    except Exception as e:
        logger.error(f"Consensus accuracy failed: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/analysis/risk-correlation", methods=["GET"])
def api_risk_correlation():
    """风险指数与回撤相关性 — 验证风险引擎有效性。"""
    period_start = request.args.get("start")
    period_end = request.args.get("end")
    try:
        stats = compute_risk_drawdown_correlation(period_start, period_end)
        return jsonify({"status": "ok", "stats": stats})
    except Exception as e:
        logger.error(f"Risk correlation failed: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/analysis/snapshot", methods=["POST"])
def api_save_snapshot():
    """保存当前统计快照，用于版本对比。"""
    data = request.get_json() or {}
    label = data.get("label")
    try:
        snapshot_id = save_snapshot(label)
        return jsonify({"status": "ok", "snapshot_id": snapshot_id})
    except Exception as e:
        logger.error(f"Snapshot save failed: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@api.route("/analysis/snapshots", methods=["GET"])
def api_snapshot_list():
    """获取所有快照列表。"""
    snapshots = get_snapshot_list()
    return jsonify({"status": "ok", "snapshots": snapshots})


@api.route("/analysis/snapshot/<int:snapshot_id>", methods=["GET"])
def api_snapshot_detail(snapshot_id):
    """获取单个快照详情。"""
    detail = get_snapshot_detail(snapshot_id)
    if not detail:
        return jsonify({"status": "error", "message": "Not found"}), 404
    return jsonify({"status": "ok", "snapshot": detail})
