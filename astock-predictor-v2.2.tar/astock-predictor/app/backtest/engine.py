"""
回测引擎 — 时间滚动回测，严格避免未来函数。
"""
import json
import logging
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

from app import db
from app.models import Feature, DailyPrice, BacktestResult, STATE_NAMES, FEATURE_COLUMNS
from app.backtest.metrics import compile_metrics

logger = logging.getLogger(__name__)


def _get_labeled_df(start_date, end_date) -> pd.DataFrame:
    """读取已标注数据。"""
    query = (
        Feature.query
        .filter(Feature.state_label.isnot(None))
        .filter(Feature.trade_date >= start_date)
        .filter(Feature.trade_date <= end_date)
        .order_by(Feature.trade_date.asc())
    )
    rows = []
    for f in query.all():
        row = {"code": f.code, "trade_date": f.trade_date, "state_label": f.state_label}
        for col in FEATURE_COLUMNS:
            row[col] = getattr(f, col, 0) or 0
        rows.append(row)
    return pd.DataFrame(rows)


def _compute_forward_returns(df: pd.DataFrame, days: int = 5) -> list:
    """计算每行的 N 日前瞻收益。"""
    returns = []
    for _, row in df.iterrows():
        code = row["code"]
        td = row["trade_date"]
        future = (
            DailyPrice.query
            .filter(DailyPrice.code == code, DailyPrice.trade_date > td)
            .order_by(DailyPrice.trade_date.asc())
            .limit(days)
            .all()
        )
        current = DailyPrice.query.get((code, td))
        if future and len(future) >= days and current and current.close > 0:
            returns.append(future[-1].close / current.close - 1)
        else:
            returns.append(None)
    return returns


def run_backtest(train_start: str, train_end: str,
                 test_start: str, test_end: str,
                 strategy_name: str = "consensus") -> dict:
    """
    执行单次回测。
    严格时间顺序：训练集在前，测试集在后。
    """
    logger.info(f"Backtest: train [{train_start}~{train_end}] test [{test_start}~{test_end}]")

    train_df = _get_labeled_df(train_start, train_end)
    test_df = _get_labeled_df(test_start, test_end)

    if train_df.empty or test_df.empty:
        logger.error("Insufficient data for backtest")
        return None

    logger.info(f"Train: {len(train_df)} samples, Test: {len(test_df)} samples")

    # 训练
    X_train = train_df[FEATURE_COLUMNS].fillna(0).values
    y_train = train_df["state_label"].values
    X_test = test_df[FEATURE_COLUMNS].fillna(0).values
    y_test = test_df["state_label"].values

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    model = LogisticRegression(
        max_iter=1000, multi_class="multinomial",
        solver="lbfgs", class_weight="balanced", C=1.0,
    )
    model.fit(X_train_s, y_train)
    y_pred = model.predict(X_test_s)

    accuracy = float(accuracy_score(y_test, y_pred))

    # 分类报告
    labels_present = sorted(set(y_test) | set(y_pred))
    target_names = [STATE_NAMES.get(l, str(l)) for l in labels_present]
    report = classification_report(y_test, y_pred, labels=labels_present,
                                   target_names=target_names, output_dict=True)
    cm = confusion_matrix(y_test, y_pred, labels=labels_present).tolist()

    # 前瞻收益分析
    test_df = test_df.copy()
    test_df["predicted_state"] = y_pred
    test_df["fwd_return_5d"] = _compute_forward_returns(test_df, days=5)

    # 拉升状态胜率
    state12_mask = test_df["predicted_state"].isin([1, 2])
    state12_returns = test_df.loc[state12_mask, "fwd_return_5d"].dropna()
    state1_5d_win_rate = float((state12_returns > 0).mean()) if len(state12_returns) > 0 else 0

    # 出货状态回撤
    state4_mask = test_df["predicted_state"] == 4
    state4_returns = test_df.loc[state4_mask, "fwd_return_5d"].dropna()
    state4_5d_drawdown = float(state4_returns.mean()) if len(state4_returns) > 0 else 0

    # 组合模拟
    equity, wins, losses, trade_returns = _simulate_portfolio(test_df)

    from app.backtest.metrics import calc_max_drawdown, calc_profit_loss_ratio, calc_sharpe_ratio
    max_dd = calc_max_drawdown(equity)
    pl_ratio = calc_profit_loss_ratio(wins, losses)
    sharpe = calc_sharpe_ratio(trade_returns)
    total_ret = equity[-1] / equity[0] - 1 if equity else 0

    # 存储
    result = BacktestResult(
        strategy_name=strategy_name,
        train_start=datetime.strptime(train_start, "%Y-%m-%d").date(),
        train_end=datetime.strptime(train_end, "%Y-%m-%d").date(),
        test_start=datetime.strptime(test_start, "%Y-%m-%d").date(),
        test_end=datetime.strptime(test_end, "%Y-%m-%d").date(),
        accuracy=accuracy,
        state1_5d_win_rate=state1_5d_win_rate,
        state4_5d_drawdown=state4_5d_drawdown,
        max_drawdown=max_dd,
        profit_loss_ratio=pl_ratio,
        sharpe_ratio=sharpe,
        total_trades=len(trade_returns),
        total_return=total_ret,
        details_json=json.dumps({
            "classification_report": report,
            "confusion_matrix": cm,
            "confusion_labels": target_names,
            "equity_curve": equity[-200:],
        }, ensure_ascii=False),
    )
    db.session.add(result)
    db.session.commit()

    return {
        "accuracy": accuracy,
        "state1_5d_win_rate": state1_5d_win_rate,
        "state4_5d_drawdown": state4_5d_drawdown,
        "max_drawdown": max_dd,
        "profit_loss_ratio": pl_ratio,
        "sharpe_ratio": sharpe,
        "total_return": total_ret,
        "total_trades": len(trade_returns),
        "train_samples": len(train_df),
        "test_samples": len(test_df),
        "classification_report": report,
        "confusion_matrix": cm,
        "confusion_labels": target_names,
        "equity_curve": equity[-200:],
    }


def _simulate_portfolio(df: pd.DataFrame):
    """简单多空组合模拟。"""
    equity = [1.0]
    wins = []
    losses = []
    trade_returns = []
    in_pos = False
    entry_ret = 0

    for _, row in df.iterrows():
        pred = row.get("predicted_state", 0)
        fwd = row.get("fwd_return_5d")

        if pred in (1, 2) and not in_pos:
            in_pos = True
            entry_ret = fwd if fwd is not None else 0

        elif pred in (4, 5) and in_pos:
            in_pos = False
            ret = entry_ret
            equity.append(equity[-1] * (1 + ret))
            trade_returns.append(ret)
            if ret > 0:
                wins.append(ret)
            else:
                losses.append(abs(ret))

        elif in_pos and fwd is not None:
            entry_ret = fwd

    return equity, wins, losses, trade_returns


def run_full_validation(config) -> dict:
    """
    完整 3 阶段验证:
    Phase 1: 2018-2022 训练 → 2023 测试
    Phase 2: 2018-2023 训练 → 2024 验证
    """
    results = {}

    logger.info("=== Phase 1: Test ===")
    r1 = run_backtest(
        config.BACKTEST_TRAIN_START, config.BACKTEST_TRAIN_END,
        config.BACKTEST_TEST_START, config.BACKTEST_TEST_END,
    )
    results["test_phase"] = r1

    logger.info("=== Phase 2: Validation ===")
    r2 = run_backtest(
        config.BACKTEST_TRAIN_START, config.BACKTEST_TEST_END,
        config.BACKTEST_VALIDATE_START, config.BACKTEST_VALIDATE_END,
    )
    results["validation_phase"] = r2

    return results
