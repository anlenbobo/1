"""
回测核心指标计算。
"""
import numpy as np


def calc_accuracy(y_true, y_pred) -> float:
    """准确率"""
    if len(y_true) == 0:
        return 0
    return float(np.mean(np.array(y_true) == np.array(y_pred)))


def calc_win_rate(returns: list) -> float:
    """胜率: 正收益占比"""
    if not returns:
        return 0
    return float(np.mean(np.array(returns) > 0))


def calc_max_drawdown(equity_curve: list) -> float:
    """最大回撤"""
    if not equity_curve:
        return 0
    arr = np.array(equity_curve)
    peak = np.maximum.accumulate(arr)
    drawdown = (peak - arr) / np.where(peak > 0, peak, 1)
    return float(np.max(drawdown))


def calc_profit_loss_ratio(wins: list, losses: list) -> float:
    """盈亏比: 平均盈利 / 平均亏损"""
    avg_win = np.mean(wins) if wins else 0
    avg_loss = np.mean(losses) if losses else 1
    return float(avg_win / avg_loss) if avg_loss > 0 else 0


def calc_sharpe_ratio(returns: list, rf: float = 0.03) -> float:
    """夏普比率 (年化)"""
    if len(returns) < 2:
        return 0
    arr = np.array(returns)
    excess = arr - rf / 252
    std = np.std(excess)
    if std == 0:
        return 0
    return float(np.mean(excess) / std * np.sqrt(252))


def calc_total_return(equity_curve: list) -> float:
    """总收益率"""
    if len(equity_curve) < 2:
        return 0
    return float(equity_curve[-1] / equity_curve[0] - 1)


def compile_metrics(y_true, y_pred, equity_curve, trade_returns, wins, losses) -> dict:
    """汇总所有指标。"""
    return {
        "accuracy": calc_accuracy(y_true, y_pred),
        "win_rate": calc_win_rate(trade_returns),
        "max_drawdown": calc_max_drawdown(equity_curve),
        "profit_loss_ratio": calc_profit_loss_ratio(wins, losses),
        "sharpe_ratio": calc_sharpe_ratio(trade_returns),
        "total_return": calc_total_return(equity_curve),
        "total_trades": len(trade_returns),
        "wins": len(wins),
        "losses": len(losses),
    }
