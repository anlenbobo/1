"""
回测报告生成。
"""
import json

from app.models import BacktestResult, STATE_NAMES


def get_backtest_history(limit: int = 20) -> list:
    """获取最近的回测记录。"""
    results = (
        BacktestResult.query
        .order_by(BacktestResult.run_date.desc())
        .limit(limit)
        .all()
    )
    return [_format_result(r) for r in results]


def get_backtest_detail(result_id: int) -> dict:
    """获取单条回测详情。"""
    r = BacktestResult.query.get(result_id)
    if not r:
        return None
    return _format_result(r, include_details=True)


def _format_result(r: BacktestResult, include_details: bool = False) -> dict:
    d = {
        "id": r.id,
        "run_date": str(r.run_date),
        "strategy_name": r.strategy_name,
        "train_period": f"{r.train_start} ~ {r.train_end}",
        "test_period": f"{r.test_start} ~ {r.test_end}",
        "accuracy": r.accuracy,
        "state1_5d_win_rate": r.state1_5d_win_rate,
        "state4_5d_drawdown": r.state4_5d_drawdown,
        "max_drawdown": r.max_drawdown,
        "profit_loss_ratio": r.profit_loss_ratio,
        "sharpe_ratio": r.sharpe_ratio,
        "total_trades": r.total_trades,
        "total_return": r.total_return,
    }
    if include_details and r.details_json:
        d["details"] = json.loads(r.details_json)
    return d
