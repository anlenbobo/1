"""
特征工程管线 — 串联所有特征计算，写入数据库。
"""
import logging

import numpy as np
import pandas as pd

from app import db
from app.models import DailyPrice, Feature
from app.feature_engine.price_features import compute_price_features
from app.feature_engine.volume_features import compute_volume_features
from app.feature_engine.capital_features import compute_capital_features
from app.feature_engine.sentiment_features import compute_sentiment_features

logger = logging.getLogger(__name__)

FEATURE_SAVE_COLS = [
    "ma5_slope", "ma20_slope", "breakout_flag", "stage_return_5d",
    "stage_return_20d", "high_position_ratio", "upper_shadow_ratio",
    "volume_change_5d", "volume_quantile", "high_turnover_flag",
    "volume_price_divergence", "net_inflow", "net_inflow_3d",
    "inflow_continuous_days", "next_day_support_rate", "big_order_ratio",
    "seal_strength_index", "limit_up_count", "max_board_height",
    "sector_strength_rank", "northbound_net", "market_sentiment_score",
    "risk_index",
]


def run_feature_pipeline(code: str,
                         northbound_df: pd.DataFrame = None,
                         capital_df: pd.DataFrame = None,
                         sentiment_cache: dict = None) -> int:
    """
    对单只股票执行完整特征工程管线。
    1. 从 daily_price 读取原始数据
    2. 依次计算 price → volume → capital → sentiment 特征
    3. 计算风险指数
    4. 写入 features 表

    返回新增特征行数。
    """
    prices = (
        DailyPrice.query.filter_by(code=code)
        .order_by(DailyPrice.trade_date.asc())
        .all()
    )
    if len(prices) < 120:
        logger.warning(f"{code}: only {len(prices)} rows, need >= 120, skipping")
        return 0

    # 构建 DataFrame
    df = pd.DataFrame([{
        "trade_date": p.trade_date,
        "open": p.open, "high": p.high, "low": p.low, "close": p.close,
        "volume": p.volume, "amount": p.amount, "turnover_rate": p.turnover_rate or 0,
    } for p in prices]).sort_values("trade_date").reset_index(drop=True)

    # 依次执行特征计算
    df = compute_price_features(df)
    df = compute_volume_features(df)
    df = compute_capital_features(df, capital_df)
    df = compute_sentiment_features(df, northbound_df, sentiment_cache)

    # 风险指数
    sentiment_decline = -df["market_sentiment_score"].diff().clip(lower=0)
    df["risk_index"] = (
        0.3 * df["high_position_ratio"].fillna(0)
        + 0.3 * df["volume_price_divergence"].clip(0, 5).fillna(0) / 5
        + 0.2 * df["max_board_height"].rank(pct=True).fillna(0)
        + 0.2 * sentiment_decline.fillna(0)
    ) * 100
    df["risk_index"] = df["risk_index"].clip(0, 100)

    # 跳过前120行 (热身期)
    df = df.iloc[120:].copy()
    df = df.replace({np.nan: None, np.inf: None, -np.inf: None})

    # 写入数据库
    count = 0
    for _, row in df.iterrows():
        td = row["trade_date"]
        feat = Feature.query.get((code, td))
        if not feat:
            feat = Feature(code=code, trade_date=td)
            db.session.add(feat)
            count += 1

        for col in FEATURE_SAVE_COLS:
            if col in row:
                setattr(feat, col, row[col])

    db.session.commit()
    logger.info(f"{code}: {count} new feature rows")
    return count


def run_feature_pipeline_batch(codes: list,
                               northbound_df=None, capital_df=None,
                               sentiment_cache=None) -> int:
    """批量运行特征管线。"""
    total = 0
    for i, code in enumerate(codes):
        logger.info(f"[{i+1}/{len(codes)}] Feature pipeline: {code}")
        try:
            total += run_feature_pipeline(code, northbound_df, capital_df, sentiment_cache)
        except Exception as e:
            logger.error(f"Feature pipeline error for {code}: {e}")
            db.session.rollback()
    return total
