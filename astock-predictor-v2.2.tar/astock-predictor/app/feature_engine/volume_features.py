"""
成交量结构特征计算。
"""
import numpy as np
import pandas as pd


def compute_volume_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    输入: 含 volume, turnover_rate, close 的 DataFrame
    输出: 添加量能特征列
    """
    df = df.copy()

    # 5日均量变化率
    vol_ma5 = df["volume"].rolling(5).mean()
    df["volume_change_5d"] = df["volume"] / vol_ma5.shift(1) - 1

    # 成交量60日分位数
    df["volume_quantile"] = df["volume"].rolling(60).rank(pct=True)

    # 高换手异常标记: 换手率 > 2倍20日均值
    turnover_ma20 = df["turnover_rate"].rolling(20).mean()
    df["high_turnover_flag"] = (df["turnover_rate"] > 2 * turnover_ma20).astype(int)

    # 量价背离指数 (5日滚动)
    price_chg = df["close"].pct_change()
    vol_chg = df["volume"].pct_change()
    divergence = np.where(
        (price_chg > 0) & (vol_chg < 0), 1,      # 价涨量缩
        np.where((price_chg < 0) & (vol_chg > 0), -1, 0)  # 价跌量增
    )
    df["volume_price_divergence"] = pd.Series(divergence, index=df.index).rolling(5).sum()

    return df
