"""
价格结构特征计算。
"""
import numpy as np
import pandas as pd


def compute_price_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    输入: 按 trade_date 升序排列的 OHLCV DataFrame
    输出: 添加价格结构特征列后的 DataFrame
    """
    df = df.copy()

    # 均线
    df["ma5"] = df["close"].rolling(5).mean()
    df["ma20"] = df["close"].rolling(20).mean()

    # 均线斜率 (5日变化率)
    df["ma5_slope"] = df["ma5"].pct_change(5)
    df["ma20_slope"] = df["ma20"].pct_change(5)

    # 突破标记: 收盘价 > 过去20日最高价
    df["rolling_high_20"] = df["high"].rolling(20).max()
    df["breakout_flag"] = (df["close"] > df["rolling_high_20"].shift(1)).astype(int)

    # 阶段收益
    df["stage_return_5d"] = df["close"].pct_change(5)
    df["stage_return_20d"] = df["close"].pct_change(20)

    # 高位比例: (当前 - 120日低) / (120日高 - 120日低)
    df["rolling_high_120"] = df["high"].rolling(120).max()
    df["rolling_low_120"] = df["low"].rolling(120).min()
    denom = df["rolling_high_120"] - df["rolling_low_120"]
    df["high_position_ratio"] = np.where(
        denom > 0,
        (df["close"] - df["rolling_low_120"]) / denom,
        0.5,
    )

    # 上影线比例
    body_top = df[["open", "close"]].max(axis=1)
    full_range = df["high"] - df["low"]
    df["upper_shadow_ratio"] = np.where(
        full_range > 0,
        (df["high"] - body_top) / full_range,
        0,
    )

    # 清理临时列
    df.drop(columns=["ma5", "ma20", "rolling_high_20", "rolling_high_120", "rolling_low_120"],
            inplace=True, errors="ignore")

    return df
