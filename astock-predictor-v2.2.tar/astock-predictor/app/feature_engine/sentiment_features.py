"""
情绪环境特征计算。
"""
import numpy as np
import pandas as pd


def compute_sentiment_features(df: pd.DataFrame,
                                northbound_df: pd.DataFrame = None,
                                sentiment_cache: dict = None) -> pd.DataFrame:
    """
    输入:
        df: 主数据 DataFrame (含 trade_date)
        northbound_df: 北向资金 DataFrame (indexed by date, column: net)
        sentiment_cache: {date: {limit_up_count, max_board_height}}
    输出: 添加情绪特征列
    """
    df = df.copy()

    df["limit_up_count"] = 0
    df["max_board_height"] = 0
    df["sector_strength_rank"] = 0.5
    df["northbound_net"] = 0.0

    # 填充北向资金
    if northbound_df is not None and not northbound_df.empty:
        for idx, row in df.iterrows():
            d = row["trade_date"]
            if d in northbound_df.index:
                df.at[idx, "northbound_net"] = float(northbound_df.loc[d, "net"])

    # 填充涨停数据
    if sentiment_cache:
        for idx, row in df.iterrows():
            d = row["trade_date"]
            if d in sentiment_cache:
                info = sentiment_cache[d]
                df.at[idx, "limit_up_count"] = info.get("limit_up_count", 0)
                df.at[idx, "max_board_height"] = info.get("max_board_height", 0)

    # 综合情绪指数
    df["market_sentiment_score"] = (
        0.3 * df["limit_up_count"].rank(pct=True).fillna(0.5)
        + 0.3 * df["max_board_height"].rank(pct=True).fillna(0.5)
        + 0.4 * df["northbound_net"].rank(pct=True).fillna(0.5)
    )

    return df
