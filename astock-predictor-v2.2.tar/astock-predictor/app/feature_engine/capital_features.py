"""
资金行为特征计算。
"""
import numpy as np
import pandas as pd


def compute_capital_features(df: pd.DataFrame, capital_df: pd.DataFrame = None) -> pd.DataFrame:
    """
    输入:
        df: 主数据 DataFrame (含 trade_date)
        capital_df: 资金流向 DataFrame (indexed by date, columns: net_inflow, big_order_ratio)
    输出: 添加资金特征列
    """
    df = df.copy()

    # 默认值
    df["net_inflow"] = 0.0
    df["net_inflow_3d"] = 0.0
    df["inflow_continuous_days"] = 0
    df["next_day_support_rate"] = 0.0
    df["big_order_ratio"] = 0.0
    df["seal_strength_index"] = 0.0

    if capital_df is None or capital_df.empty:
        return df

    # 合并资金数据
    for idx, row in df.iterrows():
        d = row["trade_date"]
        if d in capital_df.index:
            df.at[idx, "net_inflow"] = float(capital_df.loc[d, "net_inflow"])
            df.at[idx, "big_order_ratio"] = float(capital_df.loc[d, "big_order_ratio"])

    # 3日累计净流入
    df["net_inflow_3d"] = df["net_inflow"].rolling(3).sum()

    # 连续净流入天数
    continuous = 0
    cont_list = []
    for val in df["net_inflow"]:
        if val > 0:
            continuous += 1
        else:
            continuous = 0
        cont_list.append(continuous)
    df["inflow_continuous_days"] = cont_list

    # 流入后承接率: 净流入日次日涨幅均值 (滚动10日)
    next_day_ret = df["close"].pct_change().shift(-1) if "close" in df.columns else 0
    inflow_mask = df["net_inflow"] > 0
    support = np.where(inflow_mask, next_day_ret, np.nan)
    df["next_day_support_rate"] = pd.Series(support, index=df.index).rolling(10, min_periods=1).mean()

    # 封单强度 (简化: 大单占比 × 连续天数)
    df["seal_strength_index"] = (
        df["big_order_ratio"].abs().rank(pct=True) * df["inflow_continuous_days"].clip(0, 5) / 5
    )

    return df
