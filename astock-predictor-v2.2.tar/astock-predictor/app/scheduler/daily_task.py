"""
定时任务调度 — 每日收盘后自动更新。
"""
import logging
from datetime import datetime

from app.data_engine.incremental_updater import incremental_update
from app.feature_engine.feature_pipeline import run_feature_pipeline_batch
from app.alpha_engine.alpha_pipeline import run_alpha_pipeline
from app.models import Stock

logger = logging.getLogger(__name__)


def daily_update_task(app):
    """
    每日定时任务:
    1. 增量更新行情
    2. 计算特征
    3. 运行 Alpha 管线
    """
    with app.app_context():
        logger.info(f"=== Daily Task Start: {datetime.now()} ===")

        # Step 1: 增量更新
        try:
            results = incremental_update()
            total_new = sum(v for v in results.values() if v > 0)
            logger.info(f"Incremental update: {total_new} new records")
        except Exception as e:
            logger.error(f"Incremental update failed: {e}")
            return

        # Step 2: 特征计算 (只处理有新数据的股票)
        updated_codes = [code for code, n in results.items() if n > 0]
        if updated_codes:
            try:
                n_features = run_feature_pipeline_batch(updated_codes)
                logger.info(f"Features computed: {n_features}")
            except Exception as e:
                logger.error(f"Feature pipeline failed: {e}")

            # Step 3: Alpha 管线
            try:
                alpha = run_alpha_pipeline(updated_codes)
                logger.info(f"Alpha pipeline: {len(alpha.get('consensus', []))} consensus results")
            except Exception as e:
                logger.error(f"Alpha pipeline failed: {e}")

        logger.info(f"=== Daily Task Complete: {datetime.now()} ===")


def setup_scheduler(app):
    """
    配置 APScheduler 定时任务。
    需要安装: pip install apscheduler
    """
    try:
        from apscheduler.schedulers.background import BackgroundScheduler

        scheduler = BackgroundScheduler()
        hour = app.config.get("DAILY_UPDATE_HOUR", 17)
        minute = app.config.get("DAILY_UPDATE_MINUTE", 30)

        scheduler.add_job(
            func=lambda: daily_update_task(app),
            trigger="cron",
            hour=hour,
            minute=minute,
            day_of_week="mon-fri",
            id="daily_update",
            name="Daily market update",
            replace_existing=True,
        )
        scheduler.start()
        logger.info(f"Scheduler started: daily update at {hour}:{minute:02d} Mon-Fri")
        return scheduler
    except ImportError:
        logger.warning("APScheduler not installed. Run: pip install apscheduler")
        return None
