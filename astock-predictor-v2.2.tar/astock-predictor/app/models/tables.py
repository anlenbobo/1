from app import db


class Stock(db.Model):
    """股票基础信息表"""
    __tablename__ = "stocks"

    code = db.Column(db.String(10), primary_key=True)
    name = db.Column(db.String(50))
    sector = db.Column(db.String(50))
    market = db.Column(db.String(10))  # sh / sz / bj
    list_date = db.Column(db.Date)
    is_active = db.Column(db.Boolean, default=True)

    prices = db.relationship("DailyPrice", backref="stock", lazy="dynamic")
    features = db.relationship("Feature", backref="stock", lazy="dynamic")

    def __repr__(self):
        return f"<Stock {self.code} {self.name}>"


class DailyPrice(db.Model):
    """日线行情表"""
    __tablename__ = "daily_price"

    code = db.Column(db.String(10), db.ForeignKey("stocks.code"), primary_key=True)
    trade_date = db.Column(db.Date, primary_key=True)
    open = db.Column(db.Float)
    high = db.Column(db.Float)
    low = db.Column(db.Float)
    close = db.Column(db.Float)
    volume = db.Column(db.Float)
    amount = db.Column(db.Float)
    turnover_rate = db.Column(db.Float)
    pct_chg = db.Column(db.Float)  # 日涨跌幅 %

    def __repr__(self):
        return f"<DailyPrice {self.code} {self.trade_date}>"


class Feature(db.Model):
    """特征工程结果表"""
    __tablename__ = "features"

    code = db.Column(db.String(10), db.ForeignKey("stocks.code"), primary_key=True)
    trade_date = db.Column(db.Date, primary_key=True)

    # ── 价格结构特征 (price_features) ──
    ma5_slope = db.Column(db.Float)
    ma20_slope = db.Column(db.Float)
    breakout_flag = db.Column(db.Integer, default=0)
    stage_return_5d = db.Column(db.Float)
    stage_return_20d = db.Column(db.Float)
    high_position_ratio = db.Column(db.Float)
    upper_shadow_ratio = db.Column(db.Float)

    # ── 成交量结构特征 (volume_features) ──
    volume_change_5d = db.Column(db.Float)
    volume_quantile = db.Column(db.Float)
    high_turnover_flag = db.Column(db.Integer, default=0)
    volume_price_divergence = db.Column(db.Float)

    # ── 资金行为特征 (capital_features) ──
    net_inflow = db.Column(db.Float)
    net_inflow_3d = db.Column(db.Float)
    inflow_continuous_days = db.Column(db.Integer, default=0)
    next_day_support_rate = db.Column(db.Float)
    big_order_ratio = db.Column(db.Float)
    seal_strength_index = db.Column(db.Float)

    # ── 情绪环境特征 (sentiment_features) ──
    limit_up_count = db.Column(db.Integer)
    max_board_height = db.Column(db.Integer)
    sector_strength_rank = db.Column(db.Float)
    northbound_net = db.Column(db.Float)
    market_sentiment_score = db.Column(db.Float)

    # ── 状态标签 + 风险 ──
    state_label = db.Column(db.Integer)
    risk_index = db.Column(db.Float)

    def __repr__(self):
        return f"<Feature {self.code} {self.trade_date} state={self.state_label}>"

    @property
    def state_name(self):
        return STATE_NAMES.get(self.state_label, "未知")


class Signal(db.Model):
    """策略信号表"""
    __tablename__ = "signals"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    code = db.Column(db.String(10), db.ForeignKey("stocks.code"))
    trade_date = db.Column(db.Date)
    strategy_name = db.Column(db.String(50))  # leader / five_dim / momentum
    direction = db.Column(db.String(10))       # buy / sell / hold
    strength = db.Column(db.Float)             # 0~1 信号强度
    reason = db.Column(db.Text)
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    stock = db.relationship("Stock", backref="signals")

    def __repr__(self):
        return f"<Signal {self.code} {self.strategy_name} {self.direction}>"


class Prediction(db.Model):
    """共识预测结果表"""
    __tablename__ = "predictions"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    code = db.Column(db.String(10), db.ForeignKey("stocks.code"))
    trade_date = db.Column(db.Date)

    # 状态预测
    predicted_state = db.Column(db.Integer)
    prob_accumulate = db.Column(db.Float)
    prob_launch = db.Column(db.Float)
    prob_surge = db.Column(db.Float)
    prob_diverge = db.Column(db.Float)
    prob_distribute = db.Column(db.Float)
    prob_decline = db.Column(db.Float)

    # 共识结论
    consensus_direction = db.Column(db.String(10))  # buy / sell / hold
    confidence_score = db.Column(db.Float)           # 0~1
    risk_index = db.Column(db.Float)
    risk_level = db.Column(db.String(10))            # 低/中/高

    # 策略投票明细
    votes_json = db.Column(db.Text)

    created_at = db.Column(db.DateTime, server_default=db.func.now())
    stock = db.relationship("Stock", backref="predictions")

    def __repr__(self):
        return f"<Prediction {self.code} {self.trade_date} {self.consensus_direction}>"


class BacktestResult(db.Model):
    """回测结果表"""
    __tablename__ = "backtest_results"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    run_date = db.Column(db.DateTime, server_default=db.func.now())
    strategy_name = db.Column(db.String(50))  # 策略名 或 consensus
    train_start = db.Column(db.Date)
    train_end = db.Column(db.Date)
    test_start = db.Column(db.Date)
    test_end = db.Column(db.Date)

    # 核心指标
    accuracy = db.Column(db.Float)
    state1_5d_win_rate = db.Column(db.Float)
    state4_5d_drawdown = db.Column(db.Float)
    max_drawdown = db.Column(db.Float)
    profit_loss_ratio = db.Column(db.Float)
    sharpe_ratio = db.Column(db.Float)
    total_trades = db.Column(db.Integer)
    total_return = db.Column(db.Float)

    details_json = db.Column(db.Text)

    def __repr__(self):
        return f"<BacktestResult {self.id} {self.strategy_name} acc={self.accuracy}>"


class AnalysisSnapshot(db.Model):
    """统计分析快照 — 用于版本对比，追踪规则调整的效果。"""
    __tablename__ = "analysis_snapshots"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    label = db.Column(db.String(100))  # 如 "调整突破阈值前", "v2.2"
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    state_performance_json = db.Column(db.Text)     # 状态未来收益统计
    consensus_accuracy_json = db.Column(db.Text)    # 共识分层准确率
    risk_correlation_json = db.Column(db.Text)      # 风险-回撤相关性
    period_breakdown_json = db.Column(db.Text)      # 按时间段分段统计

    def __repr__(self):
        return f"<AnalysisSnapshot {self.id} {self.label}>"


# ── 全局常量 ──
STATE_NAMES = {
    0: "吸筹", 1: "启动", 2: "主升",
    3: "高位分歧", 4: "出货", 5: "退潮",
}

STATE_COLORS = {
    0: "#60a5fa", 1: "#4ade80", 2: "#f87171",
    3: "#fbbf24", 4: "#c084fc", 5: "#94a3b8",
}

FEATURE_COLUMNS = [
    "ma5_slope", "ma20_slope", "breakout_flag", "stage_return_5d",
    "stage_return_20d", "high_position_ratio", "upper_shadow_ratio",
    "volume_change_5d", "volume_quantile", "high_turnover_flag",
    "volume_price_divergence", "net_inflow", "net_inflow_3d",
    "inflow_continuous_days", "big_order_ratio", "seal_strength_index",
    "limit_up_count", "max_board_height", "sector_strength_rank",
    "northbound_net", "market_sentiment_score",
]
